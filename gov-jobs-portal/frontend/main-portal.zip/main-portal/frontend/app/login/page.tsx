"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import Link from "next/link";
import { useRouter } from "next/navigation";
import type { Route } from "next";
import { login, setToken } from "@/lib/api";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const res = await login(email, password);
      setToken(res.access_token);
      router.push("/profile" as Route);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="page">
      <div className="container" style={{ maxWidth: 460 }}>
        <motion.div className="card" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}>
          <div className="section-head" style={{ marginBottom: "1.5rem" }}>
            <span className="kicker">Welcome back</span>
            <h2 className="section-title" style={{ fontSize: "1.9rem" }}>Sign In</h2>
          </div>
          <form onSubmit={handleSubmit}>
            <div className="field">
              <label htmlFor="email">Email</label>
              <input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
            </div>
            <div className="field">
              <label htmlFor="password">Password</label>
              <input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
            </div>
            {error && <p style={{ color: "#a2171f", fontWeight: 600 }}>{error}</p>}
            <button className="btn btn--primary btn--block" type="submit" disabled={busy}>
              {busy ? "Signing in…" : "Sign In"}
            </button>
          </form>
          <p style={{ marginTop: "1rem", textAlign: "center" }}>
            Don&apos;t have an account? <Link href="/signup">Sign up free</Link>
          </p>
        </motion.div>
      </div>
    </section>
  );
}