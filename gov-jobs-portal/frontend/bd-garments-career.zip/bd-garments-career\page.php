<?php
/**
 * The template for displaying all pages.
 *
 * @package BD_Garments_Career
 */

get_header();

get_template_part( 'template-parts/hero', 'page' );
?>

<div class="container page-layout">
	<main class="page-layout__main">
		<?php
		while ( have_posts() ) :
			the_post();
			get_template_part( 'template-parts/content', 'page' );
		endwhile;
		?>
	</main>
</div>

<?php
get_footer();
