<?php
/**
 * Front page: stats (Odoo-style highlight cards).
 *
 * @package BD_Garments_Career
 */

$bdgc_stats = array(
	array( bdgc_get_option( 'bdgc_stat_1_value', '100+' ), bdgc_get_option( 'bdgc_stat_1_label', __( 'Career opportunities shared', 'bd-garments-career' ) ) ),
	array( bdgc_get_option( 'bdgc_stat_2_value', '10+' ), bdgc_get_option( 'bdgc_stat_2_label', __( 'Departments supported', 'bd-garments-career' ) ) ),
	array( bdgc_get_option( 'bdgc_stat_3_value', '24/7' ), bdgc_get_option( 'bdgc_stat_3_label', __( 'Easy access to updates', 'bd-garments-career' ) ) ),
	array( bdgc_get_option( 'bdgc_stat_4_value', 'Trusted' ), bdgc_get_option( 'bdgc_stat_4_label', __( 'Simple and reliable platform', 'bd-garments-career' ) ) ),
);
?>
<section class="stats section">
	<div class="container">
		<div class="stats__grid">
			<?php foreach ( $bdgc_stats as $bdgc_index => $bdgc_stat ) : ?>
				<div class="stat reveal" style="transition-delay:<?php echo esc_attr( ( $bdgc_index * 0.12 ) ); ?>s">
					<span class="stat__value"><?php echo esc_html( $bdgc_stat[0] ); ?></span>
					<span class="stat__label"><?php echo esc_html( $bdgc_stat[1] ); ?></span>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
</section>
