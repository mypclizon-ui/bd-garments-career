<?php
/**
 * BD Garments Career functions and definitions.
 *
 * @package BD_Garments_Career
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

define( 'BDGC_VERSION', '1.0.0' );
define( 'BDGC_DIR', get_template_directory() );
define( 'BDGC_URI', get_template_directory_uri() );

/**
 * Environment URLs.
 *
 * For production, define these in wp-config.php (recommended) or set them
 * here. If you only deploy the WordPress theme, leave the portal URLs as-is;
 * if you also deploy the Next.js + FastAPI stack, point them at the live
 * hosts (e.g. https://jobs.example.com and https://gov.example.com).
 */
if ( ! defined( 'BDGC_SERVICE_URL' ) ) {
	define( 'BDGC_SERVICE_URL', field_config_get_value( 'BDGC_SERVICE_URL', 'https://api.bdgarmentscareer.com' ) );
}
if ( ! defined( 'BDGC_GOV_PORTAL_URL' ) ) {
	define( 'BDGC_GOV_PORTAL_URL', field_config_get_value( 'BDGC_GOV_PORTAL_URL', 'https://bdgarmentscareer.com/govt-jobs' ) );
}
if ( ! defined( 'BDGC_MAIN_PORTAL_URL' ) ) {
	define( 'BDGC_MAIN_PORTAL_URL', 'https://www.bdgarmentscareer.com' );
}

/**
 * Read a value from wp-config.php constants or environment variables.
 *
 * @param string $name    Constant / env var name.
 * @param mixed  $default Fallback.
 * @return mixed
 */
function field_config_get_value( $name, $default = '' ) {
	if ( defined( $name ) ) {
		return constant( $name );
	}
	$env = getenv( $name );
	return false !== $env ? $env : $default;
}

/**
 * Theme setup.
 */
function bdgc_setup() {
	load_theme_textdomain( 'bd-garments-career', BDGC_DIR . '/languages' );

	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'custom-logo', array(
		'height'      => 80,
		'width'       => 240,
		'flex-height' => true,
		'flex-width'  => true,
	) );
	add_theme_support( 'html5', array(
		'search-form',
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
		'style',
		'script',
	) );
	add_theme_support( 'customize-selective-refresh-widgets' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'responsive-embeds' );

	add_image_size( 'bdgc-job-thumb', 640, 360, true );
	add_image_size( 'bdgc-featured', 800, 450, true );
}
add_action( 'after_setup_theme', 'bdgc_setup' );

/**
 * Register navigation menus.
 */
function bdgc_menus() {
	register_nav_menus( array(
		'primary' => __( 'Primary Menu', 'bd-garments-career' ),
		'footer'  => __( 'Footer Menu', 'bd-garments-career' ),
	) );
}
add_action( 'init', 'bdgc_menus' );

/**
 * Register widget areas.
 */
function bdgc_widgets_init() {
	register_sidebar( array(
		'name'          => __( 'Blog Sidebar', 'bd-garments-career' ),
		'id'            => 'sidebar-blog',
		'description'   => __( 'Widgets for the blog and single post pages.', 'bd-garments-career' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );
	register_sidebar( array(
		'name'          => __( 'Footer Column 1', 'bd-garments-career' ),
		'id'            => 'footer-1',
		'description'   => __( 'First footer column.', 'bd-garments-career' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h4 class="widget-title">',
		'after_title'   => '</h4>',
	) );
	register_sidebar( array(
		'name'          => __( 'Footer Column 2', 'bd-garments-career' ),
		'id'            => 'footer-2',
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h4 class="widget-title">',
		'after_title'   => '</h4>',
	) );
	register_sidebar( array(
		'name'          => __( 'Footer Column 3', 'bd-garments-career' ),
		'id'            => 'footer-3',
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h4 class="widget-title">',
		'after_title'   => '</h4>',
	) );
}
add_action( 'widgets_init', 'bdgc_widgets_init' );

/**
 * Enqueue styles and scripts.
 */
function bdgc_scripts() {
	wp_enqueue_style( 'bdgc-fonts', bdgc_fonts_url(), array(), null );
	wp_enqueue_style( 'bdgc-main', BDGC_URI . '/assets/css/main.css', array(), BDGC_VERSION );
	wp_enqueue_script( 'bdgc-main', BDGC_URI . '/assets/js/main.js', array(), BDGC_VERSION, true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'bdgc_scripts' );

/**
 * Enqueue the React job search widget on pages that contain the mount point.
 * Run `npm run build` in /react-widget first — it outputs to
 * assets/react/job-search.js + job-search.css.
 */
function bdgc_enqueue_react_widget() {
	$css_path = BDGC_DIR . '/assets/react/style.css';
	if ( file_exists( $css_path ) ) {
		wp_enqueue_style( 'bdgc-react-widgets', BDGC_URI . '/assets/react/style.css', array(), filemtime( $css_path ) );
	}

	$search_path = BDGC_DIR . '/assets/react/job-search.js';
	if ( file_exists( $search_path ) ) {
		wp_enqueue_script(
			'bdgc-job-search-widget',
			BDGC_URI . '/assets/react/job-search.js',
			array(),
			filemtime( $search_path ),
			true
		);
		wp_script_add_data( 'bdgc-job-search-widget', 'type', 'module' );

		wp_localize_script(
			'bdgc-job-search-widget',
			'bdgcJobSearch',
			array(
				'restUrl'    => esc_url_raw( rest_url( 'bdgc/v1/jobs' ) ),
				'archiveUrl' => get_post_type_archive_link( 'job' ),
				'perPage'    => 10,
				'i18n'       => array(
					'searchPlaceholder' => __( 'Job title or keyword…', 'bd-garments-career' ),
					'allCategories'     => __( 'All Categories', 'bd-garments-career' ),
					'allLocations'      => __( 'All Locations', 'bd-garments-career' ),
					'allTypes'          => __( 'All Types', 'bd-garments-career' ),
					'loading'           => __( 'Loading jobs…', 'bd-garments-career' ),
					'loadMore'          => __( 'Load more jobs', 'bd-garments-career' ),
					'empty'             => __( 'No jobs match your search.', 'bd-garments-career' ),
					'error'             => __( 'Could not load jobs. Please try again.', 'bd-garments-career' ),
					'viewLabel'         => __( 'View Details', 'bd-garments-career' ),
				),
			)
		);
	}

	// Only needed on single job pages.
	$apply_path = BDGC_DIR . '/assets/react/apply.js';
	if ( is_singular( 'job' ) && file_exists( $apply_path ) ) {
		wp_enqueue_script(
			'bdgc-apply-widget',
			BDGC_URI . '/assets/react/apply.js',
			array(),
			filemtime( $apply_path ),
			true
		);
		wp_script_add_data( 'bdgc-apply-widget', 'type', 'module' );

		wp_localize_script(
			'bdgc-apply-widget',
			'bdgcApply',
			array(
				// Point this at your deployed Python service (see
				// python-service/). Defaults to local dev.
				'serviceUrl' => defined( 'BDGC_SERVICE_URL' ) ? BDGC_SERVICE_URL : 'http://localhost:8000',
				'i18n'       => array(
					'title'         => __( 'Apply for this Job', 'bd-garments-career' ),
					'nameLabel'     => __( 'Full name', 'bd-garments-career' ),
					'emailLabel'    => __( 'Email', 'bd-garments-career' ),
					'phoneLabel'    => __( 'Phone (optional)', 'bd-garments-career' ),
					'cvLabel'       => __( 'CV link (Google Drive, LinkedIn, etc.)', 'bd-garments-career' ),
					'noteLabel'     => __( 'Cover note (optional)', 'bd-garments-career' ),
					'submit'        => __( 'Submit Application', 'bd-garments-career' ),
					'submitting'    => __( 'Submitting…', 'bd-garments-career' ),
					'successTitle'  => __( 'Application received', 'bd-garments-career' ),
					'successBody'   => __( "Thanks — we've received your application. The employer will get in touch if you're shortlisted.", 'bd-garments-career' ),
					'duplicate'     => __( "You've already applied to this job with this email.", 'bd-garments-career' ),
					'error'         => __( 'Something went wrong submitting your application. Please try again.', 'bd-garments-career' ),
					'notConfigured' => __( 'Application service is not configured yet.', 'bd-garments-career' ),
				),
			)
		);
	}
}
add_action( 'wp_enqueue_scripts', 'bdgc_enqueue_react_widget' );

/**
 * Google Fonts URL (Playfair Display for headings + Inter Tight for body).
 */
function bdgc_fonts_url() {
	$fonts = array(
		'Playfair+Display:wght@600;700;800',
		'Inter+Tight:wght@400;500;600;700;800',
	);
	return add_query_arg( array(
		'family'  => implode( '&family=', $fonts ),
		'display' => 'swap',
	), 'https://fonts.googleapis.com/css2' );
}

/**
 * Fallback for the primary menu location when no menu is assigned.
 */
function bdgc_primary_menu_fallback() {
	echo '<ul id="primary-menu" class="menu">';
	echo '<li class="menu-item"><a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'Home', 'bd-garments-career' ) . '</a></li>';
	if ( post_type_exists( 'job' ) ) {
		echo '<li class="menu-item"><a href="' . esc_url( get_post_type_archive_link( 'job' ) ) . '">' . esc_html__( 'Jobs', 'bd-garments-career' ) . '</a></li>';
	}
	echo '<li class="menu-item"><a href="' . esc_url( home_url( '/about/' ) ) . '">' . esc_html__( 'About', 'bd-garments-career' ) . '</a></li>';
	echo '<li class="menu-item"><a href="' . esc_url( home_url( '/contact/' ) ) . '">' . esc_html__( 'Contact', 'bd-garments-career' ) . '</a></li>';

	// Link to the separate government jobs portal (opens in a new tab).
	$bdgc_gov_url = defined( 'BDGC_GOV_PORTAL_URL' ) ? BDGC_GOV_PORTAL_URL : 'https://bdgarmentscareer.com/govt-jobs';
	echo '<li class="menu-item menu-item--gov"><a class="gov-portal-link" href="' . esc_url( $bdgc_gov_url ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Gov Jobs', 'bd-garments-career' ) . '</a></li>';
	echo '</ul>';
}

/**
 * Append a "Gov Jobs" item to the primary menu that opens the standalone
 * government jobs portal (a separate site) in a new tab.
 *
 * @param string   $items      HTML of the menu items.
 * @param stdClass $args       Menu args.
 * @return string
 */
function bdgc_gov_jobs_menu_item( $items, $args ) {
	if ( 'primary' !== $args->theme_location ) {
		return $items;
	}
	$gov_url = defined( 'BDGC_GOV_PORTAL_URL' )
		? BDGC_GOV_PORTAL_URL
		: 'https://bdgarmentscareer.com/govt-jobs';

	$items .= sprintf(
		'<li class="menu-item menu-item--gov"><a class="gov-portal-link" href="%1$s" target="_blank" rel="noopener noreferrer">%2$s</a></li>',
		esc_url( $gov_url ),
		esc_html__( 'Gov Jobs', 'bd-garments-career' )
	);
	return $items;
}
add_filter( 'wp_nav_menu_items', 'bdgc_gov_jobs_menu_item', 10, 2 );

/**
 * Required files.
 */
require BDGC_DIR . '/inc/customizer.php';
require BDGC_DIR . '/inc/jobs.php';
require BDGC_DIR . '/inc/helpers.php';
require BDGC_DIR . '/inc/template-tags.php';
require BDGC_DIR . '/inc/rest-api.php';

/**
 * Create the pages needed by the theme the first time it is activated.
 *
 * Runs once (guarded by a theme option) so it never duplicates or
 * overwrites pages the site owner has edited.
 */
function bdgc_activate_theme() {
	// Only run once.
	if ( get_option( 'bdgc_pages_created' ) ) {
		return;
	}

	$bdgc_pages = array(
		'home'          => array(
			'title'   => __( 'Home', 'bd-garments-career' ),
			'content' => '',
			'tpl'     => '',
		),
		'about'         => array(
			'title'   => __( 'About Us', 'bd-garments-career' ),
			'content' => __( 'Learn about who we are and what we do for the garment industry in Bangladesh.', 'bd-garments-career' ),
			'tpl'     => 'page-templates/about.php',
		),
		'contact'       => array(
			'title'   => __( 'Contact Us', 'bd-garments-career' ),
			'content' => __( 'Have a question, found a bug, or want to list your factory vacancies? We’d love to hear from you.', 'bd-garments-career' ),
			'tpl'     => 'page-templates/contact.php',
		),
		'privacy'       => array(
			'title'   => __( 'Privacy Policy', 'bd-garments-career' ),
			// translators: %s site name.
			'content' => sprintf( __( '<h2>Who we are</h2><p>%1$s is a job board connecting garment workers and employers in Bangladesh. This policy explains what information we collect and how we use it.</p><h2>Information we collect</h2><p>We collect your name, email address, phone number and CV details when you create a profile or apply for a job. We only use this information to process applications and improve our services.</p><h2>Data sharing</h2><p>We never sell your personal data. Application details are shared only with the employer you applied to.</p><h2>Contact</h2><p>Questions about this policy? Please use our contact page.</p>', 'bd-garments-career' ), get_bloginfo( 'name' ) ),
			'tpl'     => 'page-templates/info-page.php',
		),
		'terms'         => array(
			'title'   => __( 'Terms & Conditions', 'bd-garments-career' ),
			// translators: %s site name.
			'content' => sprintf( __( '<h2>Acceptance of terms</h2><p>By using %1$s you agree to these terms and conditions.</p><h2>Job seekers</h2><p>You agree to provide accurate information and apply only to jobs that genuinely interest you.</p><h2>Employers</h2><p>You agree to post genuine vacancies and to treat applicants fairly and with respect.</p><h2>Liability</h2><p>%1$s connects candidates with employers but is not responsible for the outcome of any application or hiring decision.</p>', 'bd-garments-career' ), get_bloginfo( 'name' ) ),
			'tpl'     => 'page-templates/info-page.php',
		),
		'blog'          => array(
			'title'   => __( 'Blog', 'bd-garments-career' ),
			'content' => '',
			'tpl'     => 'page-templates/blog.php',
		),
		'job-board'     => array(
			'title'   => __( 'Job Board', 'bd-garments-career' ),
			'content' => '',
			'tpl'     => 'page-templates/job-board.php',
		),
	);

	foreach ( $bdgc_pages as $bdgc_key => $bdgc_page ) {
		$bdgc_existing = get_page_by_path( sanitize_title( $bdgc_page['title'] ) );
		if ( $bdgc_existing ) {
			$bdgc_page_id = $bdgc_existing->ID;
		} else {
			$bdgc_page_id = wp_insert_post( array(
				'post_title'   => $bdgc_page['title'],
				'post_name'    => sanitize_title( $bdgc_page['title'] ),
				'post_content' => $bdgc_page['content'],
				'post_status'  => 'publish',
				'post_type'    => 'page',
			) );
		}

		if ( $bdgc_page_id && ! is_wp_error( $bdgc_page_id ) ) {
			// Assign the page template.
			if ( $bdgc_page['tpl'] ) {
				update_post_meta( $bdgc_page_id, '_wp_page_template', $bdgc_page['tpl'] );
			}
			// A subtitle shown by the page hero template part.
			if ( $bdgc_page['content'] ) {
				update_post_meta( $bdgc_page_id, '_bdgc_page_subtitle', $bdgc_page['content'] );
			}
		}
	}

	// Set the front page to the created "Home" page if nothing is set yet.
	if ( ! get_option( 'show_on_front' ) || 'posts' === get_option( 'show_on_front' ) ) {
		$bdgc_home = get_page_by_path( 'home' );
		if ( $bdgc_home ) {
			update_option( 'show_on_front', 'page' );
			update_option( 'page_on_front', $bdgc_home->ID );
		}
	}

	// Point "Blog" at the posts index page if none is set.
	if ( ! get_option( 'page_for_posts' ) ) {
		$bdgc_blog = get_page_by_path( 'blog' );
		if ( $bdgc_blog ) {
			update_option( 'page_for_posts', $bdgc_blog->ID );
		}
	}

	// Create a primary menu from the essential links if none exists.
	$bdgc_menu_name = __( 'Primary Menu', 'bd-garments-career' );
	$bdgc_menu      = wp_get_nav_menu_object( $bdgc_menu_name );
	if ( ! $bdgc_menu ) {
		$bdgc_menu_id = wp_create_nav_menu( $bdgc_menu_name );
		if ( ! is_wp_error( $bdgc_menu_id ) ) {
			foreach ( $bdgc_pages as $bdgc_key => $bdgc_page ) {
				if ( 'privacy' === $bdgc_key || 'terms' === $bdgc_key ) {
					continue; // keep legal pages out of the primary nav.
				}
				$bdgc_page_obj = get_page_by_path( sanitize_title( $bdgc_page['title'] ) );
				if ( $bdgc_page_obj ) {
					wp_update_nav_menu_item( $bdgc_menu_id, 0, array(
						'menu-item-title'     => $bdgc_page['title'],
						'menu-item-object'    => 'page',
						'menu-item-object-id' => $bdgc_page_obj->ID,
						'menu-item-type'      => 'post_type',
						'menu-item-status'    => 'publish',
					) );
				}
			}
			// Assign the menu to the primary location.
			$bdgc_locations = get_theme_mod( 'nav_menu_locations', array() );
			$bdgc_locations['primary'] = $bdgc_menu_id;
			set_theme_mod( 'nav_menu_locations', $bdgc_locations );
		}
	}

	update_option( 'bdgc_pages_created', 1 );
}

/**
 * Re-run page setup the very next request after the theme is activated,
 * as well as lazily on init for themes activated before this code existed.
 *
 * @param bool $force Whether to ignore the once-only flag.
 */
function bdgc_maybe_setup_pages() {
	if ( get_option( 'bdgc_pages_created' ) ) {
		return;
	}
	bdgc_activate_theme();
}
add_action( 'init', 'bdgc_maybe_setup_pages', 20 );

add_action( 'after_switch_theme', 'bdgc_force_theme_setup' );
function bdgc_force_theme_setup() {
	delete_option( 'bdgc_pages_created' );
	bdgc_activate_theme();
}

/**
 * Self-heal a broken front page on the front end.
 *
 * If the site is set to use a static front page but the assigned page is
 * missing or in the trash, WordPress renders a 404. This lightweight check
 * only runs on front-end requests, finds a Home page (creating it if needed)
 * and re-points the reading settings at it.
 */
function bdgc_guard_front_page() {
	if ( is_admin() ) {
		return;
	}
	if ( 'page' !== get_option( 'show_on_front' ) ) {
		return;
	}

	$front_id = (int) get_option( 'page_on_front' );
	if ( $front_id && 'trash' !== get_post_status( $front_id ) && 'publish' === get_post_status( $front_id ) ) {
		return; // Front page is fine.
	}

	$home = get_page_by_path( 'home' );
	if ( ! $home ) {
		$home_id = wp_insert_post( array(
			'post_title'   => __( 'Home', 'bd-garments-career' ),
			'post_name'    => 'home',
			'post_content' => '',
			'post_status'  => 'publish',
			'post_type'    => 'page',
		) );
	} else {
		$home_id = $home->ID;
		if ( 'trash' === $home->post_status ) {
			wp_update_post( array(
				'ID'          => $home_id,
				'post_status' => 'publish',
				'post_name'   => 'home',
			) );
		}
	}

	if ( $home_id && ! is_wp_error( $home_id ) ) {
		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $home_id );
	}
}
add_action( 'wp', 'bdgc_guard_front_page' );

/**
 * Add a "Govt Jobs" menu item in the WordPress admin dashboard.
 *
 * This opens the separate government jobs site (BDGC_GOV_PORTAL_URL) in a
 * new browser tab. It sits under the Dashboard alongside the "Garments
 * Jobs" post-type menu (both are visible in the admin sidebar).
 *
 * NOTE: No output is produced on this hook — registers the menu only.
 */
function bdgc_add_govt_jobs_admin_menu() {
	$gov_url = defined( 'BDGC_GOV_PORTAL_URL' ) ? BDGC_GOV_PORTAL_URL : 'https://bdgarmentscareer.com/govt-jobs';
	add_menu_page(
		__( 'Govt Jobs', 'bd-garments-career' ),
		__( 'Govt Jobs', 'bd-garments-career' ),
		'manage_options',
		'bdgc-govt-jobs',
		'bdgc_govt_jobs_admin_page',
		'dashicons-shield-alt',
		5 // Place it right after the Dashboard.
	);
	// The top-level item opens the external site in a new tab. The script
	// that wires target="_blank" is enqueued on admin_footer, AFTER headers
	// are sent — never output it during admin_menu.
	add_submenu_page(
		'bdgc-govt-jobs',
		__( 'Govt Jobs', 'bd-garments-career' ),
		__( 'Visit Gov Jobs Site', 'bd-garments-career' ),
		'manage_options',
		'bdgc-govt-jobs-open',
		'bdgc_govt_jobs_admin_page',
		1
	);
}
add_action( 'admin_menu', 'bdgc_add_govt_jobs_admin_menu' );

/**
 * Force the top-level "Govt Jobs" menu link to open the external site in a
 * new tab. Runs on admin_footer so no output happens before headers.
 */
function bdgc_govt_jobs_menu_target() {
	if ( ! is_admin() ) {
		return;
	}
	$gov_url = defined( 'BDGC_GOV_PORTAL_URL' ) ? BDGC_GOV_PORTAL_URL : 'https://bdgarmentscareer.com/govt-jobs';
	?>
	<script>
	document.addEventListener('DOMContentLoaded', function () {
		var a = document.querySelector('#toplevel_page_bdgc-govt-jobs > a');
		if (a) {
			a.href = <?php echo wp_json_encode( esc_url( $gov_url ) ); ?>;
			a.setAttribute('target', '_blank');
			a.setAttribute('rel', 'noopener');
		}
	});
	</script>
	<?php
}
add_action( 'admin_footer', 'bdgc_govt_jobs_menu_target' );

/**
 * Callback for the "Govt Jobs" admin menu pages. Opens the gov site and
 * returns the admin to the dashboard. Uses wp_redirect (no inline echo).
 */
function bdgc_govt_jobs_admin_page() {
	$gov_url = defined( 'BDGC_GOV_PORTAL_URL' ) ? BDGC_GOV_PORTAL_URL : 'https://bdgarmentscareer.com/govt-jobs';
	if ( ! headers_sent() ) {
		wp_redirect( $gov_url, 302 );
		exit;
	}
	echo '<p>' . esc_html__( 'Opening the government jobs site in a new tab…', 'bd-garments-career' ) . '</p>';
	echo '<script>window.open(' . wp_json_encode( esc_url( $gov_url ) ) . ', "_blank");</script>';
}
