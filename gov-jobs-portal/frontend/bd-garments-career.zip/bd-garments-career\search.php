<?php
/**
 * The template for displaying search results.
 *
 * @package BD_Garments_Career
 */

get_header();
?>

<header class="page-hero">
	<div class="container">
		<h1 class="page-hero__title">
			<?php
			/* translators: %s: search query */
			printf( esc_html__( 'Search Results for: %s', 'bd-garments-career' ), '<span class="page-hero__query">' . esc_html( get_search_query() ) . '</span>' );
			?>
		</h1>
	</div>
</header>

<div class="container archive-layout">
	<div class="archive-layout__main">
		<?php if ( have_posts() ) : ?>

			<div class="blog-grid blog-grid--list">
				<?php
				while ( have_posts() ) :
					the_post();
					get_template_part( 'template-parts/content', 'card' );
				endwhile;
				?>
			</div>

			<?php bdgc_pagination(); ?>

		<?php else : ?>
			<p class="notice"><?php esc_html_e( 'Sorry, nothing matched your search. Try different keywords.', 'bd-garments-career' ); ?></p>
		<?php endif; ?>
	</div>

	<?php get_sidebar(); ?>
</div>

<?php
get_footer();
