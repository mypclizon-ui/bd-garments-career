<?php
/**
 * The template for displaying single jobs.
 *
 * @package BD_Garments_Career
 */

get_header();
?>

<div class="container single-layout">
	<div class="single-layout__main">
		<?php
		while ( have_posts() ) :
			the_post();
			get_template_part( 'template-parts/content', 'single-job' );
		endwhile;
		?>
	</div>

	<aside class="single-layout__side">
		<div class="side-box">
			<h3 class="side-box__title"><?php esc_html_e( 'About the Company', 'bd-garments-career' ); ?></h3>
			<p><?php esc_html_e( 'Add your company description here. This sidebar can be extended with widgets or custom blocks.', 'bd-garments-career' ); ?></p>
			<?php if ( is_active_sidebar( 'sidebar-blog' ) ) : ?>
				<?php dynamic_sidebar( 'sidebar-blog' ); ?>
			<?php endif; ?>
		</div>

		<div class="side-box side-box--cta">
			<h3 class="side-box__title"><?php esc_html_e( 'Post a Job', 'bd-garments-career' ); ?></h3>
			<p><?php esc_html_e( 'Looking for workers? Reach thousands of skilled garment professionals today.', 'bd-garments-career' ); ?></p>
			<a class="btn btn--primary btn--block" href="<?php echo esc_url( home_url( '/?post_type=job' ) ); ?>">
				<?php esc_html_e( 'Post a Job', 'bd-garments-career' ); ?>
			</a>
		</div>
	</aside>
</div>

<?php
get_footer();
