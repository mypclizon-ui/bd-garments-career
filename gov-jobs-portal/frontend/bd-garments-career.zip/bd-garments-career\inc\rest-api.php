<?php
/**
 * Custom REST API for the React job search widget.
 *
 * Save this file as inc/rest-api.php inside the bd-garments-career theme
 * and require it from functions.php (see functions-php-patch.txt).
 *
 * @package BD_Garments_Career
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'BDGC_REST_NAMESPACE', 'bdgc/v1' );

/**
 * Register REST routes.
 */
function bdgc_register_rest_routes() {
	register_rest_route(
		BDGC_REST_NAMESPACE,
		'/jobs',
		array(
			'methods'             => 'GET',
			'callback'            => 'bdgc_rest_get_jobs',
			'permission_callback' => '__return_true',
			'args'                => array(
				'q'        => array( 'type' => 'string' ),
				'category' => array( 'type' => 'string' ),
				'location' => array( 'type' => 'string' ),
				'job_type' => array( 'type' => 'string' ),
				'page'     => array( 'type' => 'integer', 'default' => 1 ),
				'per_page' => array( 'type' => 'integer', 'default' => 10 ),
			),
		)
	);

	register_rest_route(
		BDGC_REST_NAMESPACE,
		'/jobs/filters',
		array(
			'methods'             => 'GET',
			'callback'            => 'bdgc_rest_get_filters',
			'permission_callback' => '__return_true',
		)
	);
}
add_action( 'rest_api_init', 'bdgc_register_rest_routes' );

/**
 * GET /bdgc/v1/jobs — filtered, paginated job list shaped for the widget.
 *
 * @param WP_REST_Request $request Request.
 * @return WP_REST_Response
 */
function bdgc_rest_get_jobs( $request ) {
	$per_page = max( 1, min( 50, (int) $request->get_param( 'per_page' ) ) );
	$page     = max( 1, (int) $request->get_param( 'page' ) );

	$args = array(
		'post_type'      => 'job',
		'posts_per_page' => $per_page,
		'paged'          => $page,
		'orderby'        => 'date',
		'order'          => 'DESC',
	);

	$search = $request->get_param( 'q' );
	if ( $search ) {
		$args['s'] = sanitize_text_field( $search );
	}

	$tax_query = array();
	foreach ( array(
		'category' => 'job_category',
		'location' => 'job_location',
	) as $param => $taxonomy ) {
		$value = $request->get_param( $param );
		if ( $value ) {
			$tax_query[] = array(
				'taxonomy' => $taxonomy,
				'field'    => 'slug',
				'terms'    => sanitize_title( $value ),
			);
		}
	}
	if ( $tax_query ) {
		$args['tax_query'] = $tax_query; // phpcs:ignore WordPress.DB.SlowDBQuery
	}

	$job_type = $request->get_param( 'job_type' );
	if ( $job_type ) {
		$args['meta_query'] = array( // phpcs:ignore WordPress.DB.SlowDBQuery
			array(
				'key'   => '_bdgc_job_type',
				'value' => sanitize_key( $job_type ),
			),
		);
	}

	$query = new WP_Query( $args );
	$types = bdgc_job_type_choices();

	$items = array();
	foreach ( $query->posts as $post ) {
		$type_key = bdgc_get_job_meta( $post->ID, 'job_type' );
		$cats     = get_the_terms( $post->ID, 'job_category' );
		$locs     = get_the_terms( $post->ID, 'job_location' );

		$items[] = array(
			'id'              => $post->ID,
			'title'           => get_the_title( $post ),
			'permalink'       => get_permalink( $post ),
			'excerpt'         => wp_trim_words( get_the_excerpt( $post ), 24 ),
			'salary'          => bdgc_get_job_meta( $post->ID, 'salary' ),
			'deadline'        => get_post_meta( $post->ID, '_bdgc_deadline', true ),
			'deadline_label'  => bdgc_get_job_meta( $post->ID, 'deadline' )
				? sprintf(
					/* translators: %s: formatted deadline date. */
					__( 'Deadline: %s', 'bd-garments-career' ),
					bdgc_get_job_meta( $post->ID, 'deadline' )
				)
				: '',
			'job_type'        => $type_key,
			'job_type_label'  => isset( $types[ $type_key ] ) ? $types[ $type_key ] : '',
			'category'        => $cats && ! is_wp_error( $cats ) ? $cats[0]->name : '',
			'location'        => $locs && ! is_wp_error( $locs ) ? $locs[0]->name : '',
			'thumbnail'       => get_the_post_thumbnail_url( $post, 'bdgc-job-thumb' ),
		);
	}

	return rest_ensure_response(
		array(
			'items'       => $items,
			'total'       => (int) $query->found_posts,
			'total_pages' => (int) $query->max_num_pages,
			'page'        => $page,
		)
	);
}

/**
 * GET /bdgc/v1/jobs/filters — categories, locations and employment types
 * for populating the widget's filter dropdowns.
 *
 * @return WP_REST_Response
 */
function bdgc_rest_get_filters() {
	$categories = get_terms( array( 'taxonomy' => 'job_category', 'hide_empty' => true ) );
	$locations  = get_terms( array( 'taxonomy' => 'job_location', 'hide_empty' => true ) );

	$format_terms = function ( $terms ) {
		if ( is_wp_error( $terms ) || ! $terms ) {
			return array();
		}
		return array_map(
			function ( $term ) {
				return array( 'slug' => $term->slug, 'name' => $term->name );
			},
			$terms
		);
	};

	$job_types = array();
	foreach ( bdgc_job_type_choices() as $value => $label ) {
		$job_types[] = array( 'value' => $value, 'label' => $label );
	}

	return rest_ensure_response(
		array(
			'categories' => $format_terms( $categories ),
			'locations'  => $format_terms( $locations ),
			'job_types'  => $job_types,
		)
	);
}
