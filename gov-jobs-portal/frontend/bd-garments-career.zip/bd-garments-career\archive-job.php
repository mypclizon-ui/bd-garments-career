<?php
/**
 * The template for displaying job archives (the "Jobs" page).
 *
 * @package BD_Garments_Career
 */

get_header();
?>

<header class="page-hero">
	<div class="container">
		<h1 class="page-hero__title"><?php esc_html_e( 'All Jobs', 'bd-garments-career' ); ?></h1>
		<p class="page-hero__desc"><?php esc_html_e( 'Browse the latest openings from garment factories, textile mills and buying houses across Bangladesh.', 'bd-garments-career' ); ?></p>
	</div>
</header>

<div class="container jobs-archive">
	<div class="jobs-archive__toolbar">
		<?php echo bdgc_render_job_search(); // phpcs:ignore WordPress.Security.EscapeOutput ?>
	</div>

	<?php if ( have_posts() ) : ?>
		<div class="jobs__list">
			<?php
			while ( have_posts() ) :
				the_post();
				get_template_part( 'template-parts/content', 'job' );
			endwhile;
			?>
		</div>

		<?php bdgc_pagination(); ?>

	<?php else : ?>
		<p class="notice"><?php esc_html_e( 'No jobs match your search. Try a different keyword or category.', 'bd-garments-career' ); ?></p>
	<?php endif; ?>
</div>

<?php
get_footer();
