<?php
/**
 * The template for displaying 404 pages (not found).
 *
 * @package BD_Garments_Career
 */

get_header();
?>

<div class="container page-layout error-404">
	<div class="page-layout__main not-found">
		<h1 class="not-found__code">404</h1>
		<h2 class="not-found__title"><?php esc_html_e( 'Page Not Found', 'bd-garments-career' ); ?></h2>
		<p><?php esc_html_e( 'The page you are looking for might have been removed or is temporarily unavailable.', 'bd-garments-career' ); ?></p>
		<p>
			<a class="btn btn--primary" href="<?php echo esc_url( home_url( '/' ) ); ?>">
				<?php esc_html_e( 'Back to Homepage', 'bd-garments-career' ); ?>
			</a>
		</p>
		<?php get_search_form(); ?>
	</div>
</div>

<?php
get_footer();
