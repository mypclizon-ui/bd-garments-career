<?php
/**
 * Template Name: About Us
 * Template Post Type: page
 *
 * A structured "About Us" page that pulls in the same content the
 * homepage About section uses, so branding stays consistent.
 *
 * @package BD_Garments_Career
 */

get_header();

get_template_part( 'template-parts/hero', 'page' );

$bdgc_about_title = bdgc_get_option( 'bdgc_about_title', __( 'About BD Garments Career', 'bd-garments-career' ) );
$bdgc_about_text  = bdgc_get_option( 'bdgc_about_text', '' );
$bdgc_points_raw  = bdgc_get_option( 'bdgc_about_points', '' );
$bdgc_points      = array_filter( array_map( 'trim', explode( "\n", $bdgc_points_raw ) ) );
$bdgc_about_img   = bdgc_get_option( 'bdgc_about_image', 0 );
?>

<main id="primary" class="site-main">
	<div class="container page-layout">
		<article id="post-<?php the_ID(); ?>" <?php post_class( 'page-layout__main' ); ?>>
			<div class="entry-content">
				<div class="section-head reveal">
					<span class="kicker"><?php esc_html_e( 'Who We Are', 'bd-garments-career' ); ?></span>
					<h2 class="section-title"><?php echo esc_html( $bdgc_about_title ); ?></h2>
					<p class="section-text"><?php echo esc_html( $bdgc_about_text ); ?></p>
				</div>

				<?php if ( $bdgc_about_img ) : ?>
					<div class="entry-thumb about-media reveal reveal-zoom">
						<img src="<?php echo esc_url( wp_get_attachment_image_url( $bdgc_about_img, 'bdgc-featured' ) ); ?>" alt="<?php echo esc_attr( $bdgc_about_title ); ?>" loading="lazy">
					</div>
				<?php endif; ?>

				<div class="project-cards reveal reveal-zoom" data-stagger>
					<div class="step-card">
						<span class="step-card__icon"><?php bdgc_icon( 'users' ); ?></span>
						<h3 class="step-card__title"><?php esc_html_e( 'Our Mission', 'bd-garments-career' ); ?></h3>
						<p class="step-card__text"><?php esc_html_e( 'To make job discovery easy and trustworthy for the hundreds of thousands of workers who power Bangladesh’s garment industry.', 'bd-garments-career' ); ?></p>
					</div>
					<div class="step-card">
						<span class="step-card__icon"><?php bdgc_icon( 'factory' ); ?></span>
						<h3 class="step-card__title"><?php esc_html_e( 'Our Vision', 'bd-garments-career' ); ?></h3>
						<p class="step-card__text"><?php esc_html_e( 'A fully transparent job market where every worker finds a fair, verified job and every factory finds the right talent.', 'bd-garments-career' ); ?></p>
					</div>
					<div class="step-card">
						<span class="step-card__icon"><?php bdgc_icon( 'check' ); ?></span>
						<h3 class="step-card__title"><?php esc_html_e( 'Our Promise', 'bd-garments-career' ); ?></h3>
						<p class="step-card__text"><?php esc_html_e( 'Free job posts for employers, verified listings for candidates, and clear, honest communication for everyone.', 'bd-garments-career' ); ?></p>
					</div>
				</div>

				<?php if ( $bdgc_points ) : ?>
					<h3><?php esc_html_e( 'Why people choose us', 'bd-garments-career' ); ?></h3>
					<ul class="check-list reveal reveal-left" data-stagger>
						<?php foreach ( $bdgc_points as $bdgc_point ) : ?>
							<li><?php echo esc_html( $bdgc_point ); ?></li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>

				<?php
				// Preserve any extra body content added by the editor.
				the_content();
				?>
			</div>
		</article>
	</div>
</main>

<?php
get_footer();