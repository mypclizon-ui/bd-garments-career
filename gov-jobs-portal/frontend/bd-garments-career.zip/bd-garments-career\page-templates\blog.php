<?php
/**
 * Template Name: Blog
 * Template Post Type: page
 *
 * A page template that shows the latest posts in the theme's blog grid,
 * with the blog sidebar. Assign this template to your "Blog" page.
 *
 * @package BD_Garments_Career
 */

get_header();

get_template_part( 'template-parts/hero', 'page' );

$bdgc_blog_page = new WP_Query( array(
	'post_type'           => 'post',
	'posts_per_page'      => 9,
	'paged'               => max( 1, (int) get_query_var( 'paged' ) ),
	'ignore_sticky_posts' => false,
) );
?>

<main id="primary" class="site-main">
	<div class="container archive-layout">
		<div class="archive-layout__main">
			<?php if ( $bdgc_blog_page->have_posts() ) : ?>
				<div class="blog-grid blog-grid--list reveal reveal-zoom" data-stagger>
					<?php
					while ( $bdgc_blog_page->have_posts() ) :
						$bdgc_blog_page->the_post();
						get_template_part( 'template-parts/content', 'card' );
					endwhile;
					wp_reset_postdata();
					?>
				</div>

				<?php
				// Reuse the main query's pagination count for proper paging.
				$bdgc_total = $bdgc_blog_page->max_num_pages;
				if ( $bdgc_total > 1 ) :
					?>
					<nav class="pagination">
						<?php
						echo paginate_links( array(
							'total'   => $bdgc_total,
							'current' => max( 1, (int) get_query_var( 'paged' ) ),
						) );
						?>
					</nav>
				<?php endif; ?>

			<?php else : ?>
				<?php get_template_part( 'template-parts/content', 'none' ); ?>
			<?php endif; ?>
		</div>

		<?php get_sidebar(); ?>
	</div>
</main>

<?php
get_footer();