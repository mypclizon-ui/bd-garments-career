<?php
/**
 * Page/archive hero banner template part.
 *
 * @package BD_Garments_Career
 */
?>
<header class="page-hero">
	<div class="container">
		<?php the_archive_title( '<h1 class="page-hero__title">', '</h1>' ); ?>
		<?php the_archive_description( '<div class="page-hero__desc">', '</div>' ); ?>
	</div>
</header>
