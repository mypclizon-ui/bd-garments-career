<?php
/**
 * Front page: featured section content.
 *
 * @package BD_Garments_Career
 */
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<?php if ( has_post_thumbnail() ) : ?>
		<div class="entry-thumb">
			<?php the_post_thumbnail( 'bdgc-featured' ); ?>
		</div>
	<?php endif; ?>
	<div class="entry-content">
		<?php
		the_content();
		wp_link_pages();
		?>
	</div>
</article>
