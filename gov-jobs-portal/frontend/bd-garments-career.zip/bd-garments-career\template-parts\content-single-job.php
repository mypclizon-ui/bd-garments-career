<?php
/**
 * Single job content.
 *
 * @package BD_Garments_Career
 */

$bdgc_types   = bdgc_job_type_choices();
$bdgc_type    = bdgc_get_job_meta( get_the_ID(), 'job_type' );
$bdgc_loc     = get_the_terms( get_the_ID(), 'job_location' );
$bdgc_cats    = get_the_terms( get_the_ID(), 'job_category' );
$bdgc_salary  = bdgc_get_job_meta( get_the_ID(), 'salary' );
$bdgc_dead    = get_post_meta( get_the_ID(), '_bdgc_deadline', true );
$bdgc_exp     = bdgc_get_job_meta( get_the_ID(), 'experience' );
$bdgc_dead_dt = $bdgc_dead ? gmdate( 'Y-m-d', strtotime( $bdgc_dead ) ) : '';
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'single-job' ); ?>>
	<div class="job-summary">
		<div class="job-summary__title">
			<?php the_title( '<h1 class="single-job__title">', '</h1>' ); ?>
			<?php if ( $bdgc_type && isset( $bdgc_types[ $bdgc_type ] ) ) : ?>
				<span class="badge badge--lg"><?php echo esc_html( $bdgc_types[ $bdgc_type ] ); ?></span>
			<?php endif; ?>
		</div>

		<ul class="job-summary__facts">
			<?php if ( $bdgc_cats ) : ?>
				<li>
					<span class="job-fact__label"><?php esc_html_e( 'Category', 'bd-garments-career' ); ?></span>
					<span class="job-fact__value"><?php echo esc_html( $bdgc_cats[0]->name ); ?></span>
				</li>
			<?php endif; ?>
			<?php if ( $bdgc_loc ) : ?>
				<li>
					<span class="job-fact__label"><?php esc_html_e( 'Location', 'bd-garments-career' ); ?></span>
					<span class="job-fact__value"><?php echo esc_html( $bdgc_loc[0]->name ); ?></span>
				</li>
			<?php endif; ?>
			<?php if ( $bdgc_salary ) : ?>
				<li>
					<span class="job-fact__label"><?php esc_html_e( 'Salary', 'bd-garments-career' ); ?></span>
					<span class="job-fact__value"><?php echo esc_html( $bdgc_salary ); ?></span>
				</li>
			<?php endif; ?>
			<?php if ( $bdgc_exp ) : ?>
				<li>
					<span class="job-fact__label"><?php esc_html_e( 'Experience', 'bd-garments-career' ); ?></span>
					<span class="job-fact__value"><?php echo esc_html( $bdgc_exp ); ?></span>
				</li>
			<?php endif; ?>
		</ul>
	</div>

	<?php if ( has_post_thumbnail() ) : ?>
		<div class="single-job__media">
			<?php the_post_thumbnail( 'bdgc-featured' ); ?>
		</div>
	<?php endif; ?>

	<div class="entry-content">
		<?php the_content(); ?>
	</div>

	<?php if ( $bdgc_dead_dt ) : ?>
		<div class="job-apply">
			<p class="job-apply__hint">
				<?php
				printf(
					/* translators: %s: deadline date */
					esc_html__( 'Apply before %s.', 'bd-garments-career' ),
					esc_html( date_i18n( get_option( 'date_format' ), strtotime( $bdgc_dead_dt ) ) )
				);
				?>
			</p>
			<a class="btn btn--primary btn--lg" href="#job-apply-form"><?php esc_html_e( 'Apply for this Job', 'bd-garments-career' ); ?></a>
		</div>
	<?php endif; ?>

	<div id="job-apply-form">
		<div id="bdgc-apply-root" data-job-id="<?php the_ID(); ?>"></div>

		<noscript>
			<div class="job-apply-box">
				<h2><?php esc_html_e( 'Apply for this Job', 'bd-garments-career' ); ?></h2>
				<p>
					<?php esc_html_e( 'Please email your CV to the factory directly. Mention the job title in the subject line.', 'bd-garments-career' ); ?>
				</p>
				<?php
				$bdgc_email = bdgc_get_option( 'bdgc_email', '' );
				if ( $bdgc_email ) :
					?>
					<a class="btn btn--outline btn--lg" href="mailto:<?php echo esc_attr( $bdgc_email ); ?>?subject=<?php echo rawurlencode( get_the_title() ); ?>">
						<?php esc_html_e( 'Email Your CV', 'bd-garments-career' ); ?>
					</a>
				<?php endif; ?>
			</div>
		</noscript>
	</div>
</article>
