<?php
/**
 * Front page: how it works (3 steps).
 *
 * @package BD_Garments_Career
 */

$bdgc_steps = array(
	array(
		'bdgc_icon' => 'user',
		'bdgc_num'  => '01',
		'bdgc_t'    => __( 'Create a Profile', 'bd-garments-career' ),
		'bdgc_d'    => __( 'Sign up free as a job seeker or a factory HR manager. It takes less than two minutes.', 'bd-garments-career' ),
	),
	array(
		'bdgc_icon' => 'search',
		'bdgc_num'  => '02',
		'bdgc_t'    => __( 'Search & Apply', 'bd-garments-career' ),
		'bdgc_d'    => __( 'Filter jobs by category, location and type. Apply with one tap from your phone.', 'bd-garments-career' ),
	),
	array(
		'bdgc_icon' => 'check',
		'bdgc_num'  => '03',
		'bdgc_t'    => __( 'Get Hired', 'bd-garments-career' ),
		'bdgc_d'    => __( 'Factories contact you directly for interviews. Start your new job with confidence.', 'bd-garments-career' ),
	),
);
?>
<section class="how section" id="how">
	<div class="container">
		<div class="reveal">
			<?php
			bdgc_section_heading(
				__( 'Simple Process', 'bd-garments-career' ),
				bdgc_get_option( 'bdgc_how_title', __( 'How It Works', 'bd-garments-career' ) )
			);
			?>
		</div>

		<div class="how__grid reveal reveal-zoom" data-stagger>
			<?php foreach ( $bdgc_steps as $bdgc_step ) : ?>
				<div class="step-card">
					<span class="step-card__num"><?php echo esc_html( $bdgc_step['bdgc_num'] ); ?></span>
					<span class="step-card__icon"><?php bdgc_icon( $bdgc_step['bdgc_icon'] ); ?></span>
					<h3 class="step-card__title"><?php echo esc_html( $bdgc_step['bdgc_t'] ); ?></h3>
					<p class="step-card__text"><?php echo esc_html( $bdgc_step['bdgc_d'] ); ?></p>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
</section>
