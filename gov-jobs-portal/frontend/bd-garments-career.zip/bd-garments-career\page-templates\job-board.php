<?php
/**
 * Template Name: Job Board
 * Template Post Type: page
 *
 * Searchable job board. The React widget (assets/react/job-search.js) owns
 * the search form + results once it mounts; the PHP-rendered list below is
 * a no-JS fallback that stays hidden once React takes over.
 *
 * @package BD_Garments_Career
 */

get_header();

get_template_part( 'template-parts/hero', 'page' );

$bdgc_jobs_page = new WP_Query( array(
	'post_type'      => 'job',
	'posts_per_page' => 10,
	'paged'          => max( 1, (int) get_query_var( 'paged' ) ),
) );
?>

<div class="container jobs-archive">

	<!-- React mounts here. See wp-theme-patch/ for the widget + REST API. -->
	<div id="bdgc-job-search-root"></div>

	<noscript>
		<div class="jobs-archive__toolbar">
			<?php echo bdgc_render_job_search(); // phpcs:ignore WordPress.Security.EscapeOutput ?>
		</div>

		<?php if ( $bdgc_jobs_page->have_posts() ) : ?>
			<div class="jobs__list">
				<?php
				while ( $bdgc_jobs_page->have_posts() ) :
					$bdgc_jobs_page->the_post();
					get_template_part( 'template-parts/content', 'job' );
				endwhile;
				wp_reset_postdata();
				?>
			</div>

			<?php if ( $bdgc_jobs_page->max_num_pages > 1 ) : ?>
				<nav class="pagination">
					<?php
					echo paginate_links( array( // phpcs:ignore WordPress.Security.EscapeOutput
						'total'   => $bdgc_jobs_page->max_num_pages,
						'current' => max( 1, (int) get_query_var( 'paged' ) ),
					) );
					?>
				</nav>
			<?php endif; ?>

		<?php else : ?>
			<p class="notice"><?php esc_html_e( 'No jobs posted yet.', 'bd-garments-career' ); ?></p>
		<?php endif; ?>
	</noscript>

</div>

<?php
get_footer();
