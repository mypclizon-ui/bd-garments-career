<?php
/**
 * Helper functions for BD Garments Career.
 *
 * @package BD_Garments_Career
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Get a Customizer setting with a default fallback.
 *
 * @param string $key     Setting key.
 * @param mixed  $default Fallback value.
 * @return mixed
 */
function bdgc_get_option( $key, $default = '' ) {
	return get_theme_mod( $key, $default );
}

/**
 * Whether the site is running in Bengali-first mode.
 */
function bdgc_is_bengali() {
	return 'bn' === get_bloginfo( 'language' );
}

/**
 * Output a section heading block (kicker + title + text).
 *
 * @param string $kicker Section kicker.
 * @param string $title  Section title.
 * @param string $text   Optional intro text.
 * @param bool   $center Center the heading.
 */
function bdgc_section_heading( $kicker, $title, $text = '', $center = true ) {
	?>
	<div class="section-head <?php echo $center ? 'is-center' : ''; ?>">
		<?php if ( $kicker ) : ?>
			<span class="kicker"><?php echo esc_html( $kicker ); ?></span>
		<?php endif; ?>
		<h2 class="section-title"><?php echo esc_html( $title ); ?></h2>
		<?php if ( $text ) : ?>
			<p class="section-text"><?php echo esc_html( $text ); ?></p>
		<?php endif; ?>
	</div>
	<?php
}

/**
 * Compose a phone / email / address string for display.
 */
function bdgc_contact_lines() {
	$lines = array();
	$phone = bdgc_get_option( 'bdgc_phone', '' );
	$email = bdgc_get_option( 'bdgc_email', '' );
	$addr  = bdgc_get_option( 'bdgc_address', '' );

	if ( $phone ) {
		$lines[] = sprintf( '<a href="tel:%1$s">%1$s</a>', esc_attr( preg_replace( '/[^0-9+]/', '', $phone ) ) );
	}
	if ( $email ) {
		$lines[] = sprintf( '<a href="mailto:%1$s">%1$s</a>', esc_attr( $email ) );
	}
	if ( $addr ) {
		$lines[] = esc_html( $addr );
	}
	return $lines;
}

/**
 * Sanitize a phone number into digits/plus only.
 */
function bdgc_sanitize_phone( $value ) {
	return preg_replace( '/[^0-9+]/', '', $value );
}
