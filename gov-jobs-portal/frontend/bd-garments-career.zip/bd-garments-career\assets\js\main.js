/**
 * BD Garments Career front-end scripts.
 */
(function () {
	'use strict';

	var toggle = document.querySelector('.nav-toggle');
	var menu = document.getElementById('primary-menu');

	if (toggle && menu) {
		toggle.addEventListener('click', function () {
			var open = menu.classList.toggle('open');
			toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
		});
	}

	// Close the mobile menu after tapping a link.
	document.addEventListener('click', function (e) {
		if (!menu) {
			return;
		}
		var isLink = e.target.closest('#primary-menu a');
		if (isLink && menu.classList.contains('open')) {
			menu.classList.remove('open');
			toggle.setAttribute('aria-expanded', 'false');
		}
	});

	// --- Reveal-on-scroll (fade/slide in) ---------------------------------
	var revealEls = document.querySelectorAll('.reveal');
	if (revealEls.length && 'IntersectionObserver' in window) {
		var io = new IntersectionObserver(function (entries) {
			entries.forEach(function (entry) {
				if (entry.isIntersecting) {
					var el = entry.target;
					// Set per-child stagger delay for data-stagger parents.
					if (el.hasAttribute('data-stagger')) {
						Array.prototype.forEach.call(el.children, function (child, i) {
							child.style.setProperty('--stagger-index', i.toString());
						});
					}
					el.classList.add('is-visible');
					io.unobserve(el);
				}
			});
		}, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

		revealEls.forEach(function (el) { io.observe(el); });
	} else {
		revealEls.forEach(function (el) { el.classList.add('is-visible'); });
	}

	// --- Sticky header elevation on scroll --------------------------------
	var header = document.getElementById('masthead');
	if (header) {
		var onScroll = function () {
			if (window.scrollY > 8) {
				header.classList.add('is-scrolled');
			} else {
				header.classList.remove('is-scrolled');
			}
		};
		window.addEventListener('scroll', onScroll, { passive: true });
		onScroll();
	}

	// --- Animated number counters for the stats bar ------------------------
	var counters = document.querySelectorAll('.stat__value');
	if (counters.length && 'IntersectionObserver' in window) {
		var counterIO = new IntersectionObserver(function (entries) {
			entries.forEach(function (entry) {
				if (!entry.isIntersecting) {
					return;
				}
				var el = entry.target;
				counterIO.unobserve(el);

				var raw = el.textContent.trim();
				if (!/^\d/.test(raw)) {
					return; // leave "24/7", "Trusted", custom values alone
				}
				var suffix = raw.replace(/^[\d.]+/, '');
				var target = parseFloat(raw);
				if (isNaN(target)) {
					return;
				}
				var start = null;
				var duration = 1600;
				var step = function (ts) {
					if (start === null) {
						start = ts;
					}
					var progress = Math.min((ts - start) / duration, 1);
					var eased = 1 - Math.pow(1 - progress, 3);
					el.textContent = Math.round(target * eased).toString() + suffix;
					if (progress < 1) {
						requestAnimationFrame(step);
					}
				};
				requestAnimationFrame(step);
			});
		}, { threshold: 0.6 });

		counters.forEach(function (el) { counterIO.observe(el); });
	}

	// --- Partner logo slider -----------------------------------------------
	var track = document.getElementById('bdgc-partners-track');
	if (track) {
		var prevBtn = document.querySelector('.partners-slider__btn--prev');
		var nextBtn = document.querySelector('.partners-slider__btn--next');
		var slideBy = function (dir) {
			var item = track.querySelector('.partner-item');
			if (!item) {
				return;
			}
			var gap = getComputedStyle(track).columnGap || '0px';
			var step = item.offsetWidth + (parseFloat(gap) || 0);
			track.scrollBy({ left: dir * step, behavior: 'smooth' });
		};

		if (prevBtn) {
			prevBtn.addEventListener('click', function () { slideBy(-1); });
		}
		if (nextBtn) {
			nextBtn.addEventListener('click', function () { slideBy(1); });
		}

		// Update button disabled states as the track reaches its ends.
		var updateArrows = function () {
			var maxLeft = track.scrollWidth - track.clientWidth;
			if (prevBtn) { prevBtn.disabled = track.scrollLeft <= 2; }
			if (nextBtn) { nextBtn.disabled = track.scrollLeft >= maxLeft - 2; }
		};
		track.addEventListener('scroll', updateArrows, { passive: true });
		window.addEventListener('resize', updateArrows);
		updateArrows();

		// Autoplay: advance a slide every few seconds, pause on hover.
		var autoplay = setInterval(function () {
			var maxLeft = track.scrollWidth - track.clientWidth;
			if (track.scrollLeft >= maxLeft - 2) {
				track.scrollTo({ left: 0, behavior: 'smooth' });
			} else {
				slideBy(1);
			}
			updateArrows();
		}, 3500);

		track.addEventListener('mouseenter', function () { clearInterval(autoplay); });
		track.addEventListener('mouseleave', function () {
			autoplay = setInterval(function () {
				updateArrows();
				var maxLeft = track.scrollWidth - track.clientWidth;
				if (track.scrollLeft >= maxLeft - 2) {
					track.scrollTo({ left: 0, behavior: 'smooth' });
				} else {
					slideBy(1);
				}
			}, 3500);
		});
	}
})();