<?php
/**
 * The template for displaying all single posts (blog).
 *
 * @package BD_Garments_Career
 */

get_header();
?>

<div class="container archive-layout">
	<div class="archive-layout__main">
		<?php
		while ( have_posts() ) :
			the_post();
			get_template_part( 'template-parts/content', 'single-post' );

			the_post_navigation( array(
				'prev_text' => '<span class="meta-nav">&larr;</span> %title',
				'next_text' => '%title <span class="meta-nav">&rarr;</span>',
			) );

			if ( comments_open() || get_comments_number() ) :
				comments_template();
			endif;

		endwhile;
		?>
	</div>

	<?php get_sidebar(); ?>
</div>

<?php
get_footer();
