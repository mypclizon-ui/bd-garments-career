<?php
/**
 * The footer for our theme.
 *
 * @package BD_Garments_Career
 */
?>
</main><!-- #primary -->

<footer class="site-footer">
	<div class="container">
		<div class="footer-grid">
			<div class="footer-col footer-col--about">
				<div class="site-branding footer-brand">
					<?php bdgc_site_logo(); ?>
				</div>
				<p class="footer-about"><?php echo wp_kses_post( bdgc_get_option( 'bdgc_footer_text', __( 'Empowering the workforce behind Bangladesh’s garment export industry.', 'bd-garments-career' ) ) ); ?></p>
				<?php
				$contact_lines = bdgc_contact_lines();
				if ( $contact_lines ) :
					?>
					<ul class="footer-contact">
						<?php foreach ( $contact_lines as $line ) : ?>
							<li><?php echo $line; // phpcs:ignore WordPress.Security.EscapeOutput ?></li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
			</div>

			<div class="footer-col">
				<?php if ( is_active_sidebar( 'footer-1' ) ) : ?>
					<?php dynamic_sidebar( 'footer-1' ); ?>
				<?php endif; ?>
			</div>
			<div class="footer-col">
				<?php if ( is_active_sidebar( 'footer-2' ) ) : ?>
					<?php dynamic_sidebar( 'footer-2' ); ?>
				<?php endif; ?>
			</div>
			<div class="footer-col">
				<?php if ( is_active_sidebar( 'footer-3' ) ) : ?>
					<?php dynamic_sidebar( 'footer-3' ); ?>
				<?php endif; ?>
			</div>
		</div>

		<div class="footer-bottom">
			<p><?php bdgc_copyright(); ?></p>
			<nav class="footer-nav" aria-label="<?php esc_attr_e( 'Footer', 'bd-garments-career' ); ?>">
				<?php
				wp_nav_menu( array(
					'theme_location' => 'footer',
					'container'      => 'ul',
					'depth'          => 1,
					'fallback_cb'    => false,
				) );
				?>
			</nav>
		</div>
	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
