<?php
/**
 * The main template file (blog index / fallback).
 *
 * @package BD_Garments_Career
 */

get_header();
?>

<div class="container archive-layout">
	<div class="archive-layout__main">
		<?php if ( have_posts() ) : ?>

			<?php if ( is_home() && ! is_front_page() ) : ?>
				<header class="page-hero page-hero--inline">
					<h1 class="page-hero__title"><?php single_post_title(); ?></h1>
				</header>
			<?php endif; ?>

			<div class="blog-grid blog-grid--list">
				<?php
				while ( have_posts() ) :
					the_post();
					get_template_part( 'template-parts/content', 'card' );
				endwhile;
				?>
			</div>

			<?php bdgc_pagination(); ?>

		<?php else : ?>

			<?php get_template_part( 'template-parts/content', 'none' ); ?>

		<?php endif; ?>
	</div>

	<?php get_sidebar(); ?>
</div>

<?php
get_footer();
