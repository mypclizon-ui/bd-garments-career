<?php
/**
 * Job taxonomy archive template (categories, locations, types).
 *
 * @package BD_Garments_Career
 */

get_header();
?>

<header class="page-hero">
	<div class="container">
		<h1 class="page-hero__title"><?php single_term_title(); ?></h1>
		<?php if ( term_description() ) : ?>
			<p class="page-hero__desc"><?php echo wp_kses_post( term_description() ); ?></p>
		<?php endif; ?>
	</div>
</header>

<div class="container jobs-archive">
	<?php if ( have_posts() ) : ?>
		<div class="jobs__list">
			<?php
			while ( have_posts() ) :
				the_post();
				get_template_part( 'template-parts/content', 'job' );
			endwhile;
			?>
		</div>

		<?php bdgc_pagination(); ?>

	<?php else : ?>
		<p class="notice"><?php esc_html_e( 'No jobs in this category yet.', 'bd-garments-career' ); ?></p>
	<?php endif; ?>
</div>

<?php
get_footer();
