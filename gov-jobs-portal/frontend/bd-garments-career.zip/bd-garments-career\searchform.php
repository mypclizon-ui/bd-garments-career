<?php
/**
 * The search form for our theme.
 *
 * A compact, icon-first search field used in the top bar and the 404
 * page. The search icon is an inline SVG so no icon font is required.
 *
 * @package BD_Garments_Career
 */
?>
<form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label class="search-form__field">
		<span class="screen-reader-text"><?php esc_html_e( 'Search for:', 'bd-garments-career' ); ?></span>
		<svg xmlns="http://www.w3.org/2000/svg" class="search-form__icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
		<input type="search" class="search-field" placeholder="<?php esc_attr_e( 'Search…', 'bd-garments-career' ); ?>" value="<?php echo esc_attr( get_search_query() ); ?>" name="s">
	</label>
	<button type="submit" class="search-submit">
		<span class="screen-reader-text"><?php esc_html_e( 'Search', 'bd-garments-career' ); ?></span>
		<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
	</button>
</form>