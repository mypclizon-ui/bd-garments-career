<?php
/**
 * Front page: call to action band.
 *
 * @package BD_Garments_Career
 */

$bdgc_cta_title = bdgc_get_option( 'bdgc_cta_title', __( 'Are You Hiring for Your Factory?', 'bd-garments-career' ) );
$bdgc_cta_text  = bdgc_get_option( 'bdgc_cta_text', '' );
$bdgc_cta_btn   = bdgc_get_option( 'bdgc_cta_btn_text', __( 'Post a Job Now', 'bd-garments-career' ) );
$bdgc_cta_url   = bdgc_get_option( 'bdgc_cta_btn_url', '#contact' );
?>
<section class="cta section">
	<div class="container cta__inner">
		<div class="cta__content reveal reveal-left">
			<h2 class="cta__title"><?php echo esc_html( $bdgc_cta_title ); ?></h2>
			<?php if ( $bdgc_cta_text ) : ?>
				<p class="cta__text"><?php echo esc_html( $bdgc_cta_text ); ?></p>
			<?php endif; ?>
		</div>
		<div class="cta__action reveal reveal-right">
			<a class="btn btn--light btn--lg" href="<?php echo esc_url( $bdgc_cta_url ); ?>"><?php echo esc_html( $bdgc_cta_btn ); ?></a>
		</div>
	</div>
</section>
