<?php
/**
 * Template Name: Contact
 * Template Post Type: page
 *
 * A contact page template with a simple contact form and company info.
 * To receive messages, connect the form to a plugin such as WPForms or
 * Contact Form 7, or configure the mailto action below.
 *
 * @package BD_Garments_Career
 */

get_header();

get_template_part( 'template-parts/hero', 'page' );
?>

<div class="container contact-layout">
	<main class="contact-layout__info">
		<h2><?php esc_html_e( 'Get in Touch', 'bd-garments-career' ); ?></h2>
		<p><?php esc_html_e( 'Have a question about a job, or want to list your factory vacancies? Send us a message and our team will get back to you within 24 hours.', 'bd-garments-career' ); ?></p>

		<ul class="contact-list">
			<?php
			$bdgc_lines = bdgc_contact_lines();
			foreach ( $bdgc_lines as $bdgc_line ) :
				?>
				<li><?php echo $bdgc_line; // phpcs:ignore WordPress.Security.EscapeOutput ?></li>
			<?php endforeach; ?>
		</ul>

		<?php
		$bdgc_facebook = bdgc_get_option( 'bdgc_facebook', '' );
		if ( $bdgc_facebook ) :
			?>
			<p>
				<a class="btn btn--outline" href="<?php echo esc_url( $bdgc_facebook ); ?>" target="_blank" rel="noopener">
					<?php esc_html_e( 'Follow us on Facebook', 'bd-garments-career' ); ?>
				</a>
			</p>
		<?php endif; ?>
	</main>

	<main class="contact-layout__form">
		<form class="contact-form" action="mailto:<?php echo esc_attr( bdgc_get_option( 'bdgc_email', '' ) ); ?>" method="post" enctype="text/plain">
			<p>
				<label for="cf-name"><?php esc_html_e( 'Your Name', 'bd-garments-career' ); ?></label>
				<input type="text" id="cf-name" name="name" required>
			</p>
			<p>
				<label for="cf-email"><?php esc_html_e( 'Your Email', 'bd-garments-career' ); ?></label>
				<input type="email" id="cf-email" name="email" required>
			</p>
			<p>
				<label for="cf-subject"><?php esc_html_e( 'Subject', 'bd-garments-career' ); ?></label>
				<input type="text" id="cf-subject" name="subject" required>
			</p>
			<p>
				<label for="cf-message"><?php esc_html_e( 'Message', 'bd-garments-career' ); ?></label>
				<textarea id="cf-message" name="message" rows="6" required></textarea>
			</p>
			<p>
				<button type="submit" class="btn btn--primary btn--lg"><?php esc_html_e( 'Send Message', 'bd-garments-career' ); ?></button>
			</p>
		</form>
		<p class="form-note"><?php esc_html_e( 'Note: This demo form opens your email app. For a production form, use WPForms or Contact Form 7.', 'bd-garments-career' ); ?></p>
	</main>
</div>

<?php
get_footer();
