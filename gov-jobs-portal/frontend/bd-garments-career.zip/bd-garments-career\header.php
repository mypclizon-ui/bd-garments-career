<?php
/**
 * The header for our theme.
 *
 * @package BD_Garments_Career
 */

$bdgc_facebook = bdgc_get_option( 'bdgc_facebook', '' );
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e( 'Skip to content', 'bd-garments-career' ); ?></a>

<div class="topbar">
	<div class="container topbar__inner">
		<div class="topbar__social">
			<?php if ( $bdgc_facebook ) : ?>
				<a class="topbar__social-link" href="<?php echo esc_url( $bdgc_facebook ); ?>" target="_blank" rel="noopener" aria-label="Facebook">
					<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>
				</a>
			<?php endif; ?>
			<span class="topbar__label"><?php esc_html_e( 'Trusted Garments Career Portal in Bangladesh', 'bd-garments-career' ); ?></span>
		</div>
		<div class="topbar__right">
			<?php get_search_form(); ?>
			<a class="topbar__btn" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>"><?php esc_html_e( 'Contact Us', 'bd-garments-career' ); ?></a>
		</div>
	</div>
</div>

<header class="site-header" id="masthead">
	<div class="container site-header__inner">
		<div class="site-branding">
			<?php bdgc_site_logo(); ?>
		</div>

		<nav class="main-nav" aria-label="<?php esc_attr_e( 'Primary', 'bd-garments-career' ); ?>">
			<button class="nav-toggle" aria-expanded="false" aria-controls="primary-menu">
				<span class="nav-toggle__bar"></span>
				<span class="nav-toggle__bar"></span>
				<span class="nav-toggle__bar"></span>
				<span class="screen-reader-text"><?php esc_html_e( 'Menu', 'bd-garments-career' ); ?></span>
			</button>
			<?php
			wp_nav_menu( array(
				'theme_location' => 'primary',
				'menu_id'        => 'primary-menu',
				'container'      => 'ul',
				'fallback_cb'    => 'bdgc_primary_menu_fallback',
			) );
			?>
		</nav>

		<div class="header-actions">
			<a class="header-link" href="<?php echo esc_url( wp_login_url() ); ?>"><?php esc_html_e( 'Sign In', 'bd-garments-career' ); ?></a>
			<a class="btn btn--primary btn--sm" href="<?php echo esc_url( home_url( '/?post_type=job' ) ); ?>">
				<?php esc_html_e( 'Post a Job', 'bd-garments-career' ); ?>
			</a>
		</div>
	</div>
</header>

<main id="primary" class="site-main">
