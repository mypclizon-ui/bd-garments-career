<?php
/**
 * Job custom post type, taxonomies and meta for BD Garments Career.
 *
 * @package BD_Garments_Career
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register the "job" post type.
 */
function bdgc_register_job_type() {
	$labels = array(
		'name'               => __( 'Garments Jobs', 'bd-garments-career' ),
		'singular_name'      => __( 'Garments Job', 'bd-garments-career' ),
		'add_new'            => __( 'Add New Garments Job', 'bd-garments-career' ),
		'add_new_item'       => __( 'Add New Garments Job', 'bd-garments-career' ),
		'edit_item'          => __( 'Edit Garments Job', 'bd-garments-career' ),
		'new_item'           => __( 'New Garments Job', 'bd-garments-career' ),
		'view_item'          => __( 'View Garments Job', 'bd-garments-career' ),
		'search_items'       => __( 'Search Garments Jobs', 'bd-garments-career' ),
		'not_found'          => __( 'No garments jobs found.', 'bd-garments-career' ),
		'not_found_in_trash' => __( 'No garments jobs found in Trash.', 'bd-garments-career' ),
		'featured_image'     => __( 'Job Image', 'bd-garments-career' ),
		'set_featured_image' => __( 'Set job image', 'bd-garments-career' ),
		'menu_name'          => __( 'Garments Jobs', 'bd-garments-career' ),
	);

	register_post_type( 'job', array(
		'labels'       => $labels,
		'public'       => true,
		'has_archive'  => true,
		'rewrite'      => array( 'slug' => 'jobs', 'with_front' => false ),
		'menu_icon'    => 'dashicons-portfolio',
		'supports'     => array( 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ),
		'show_in_rest' => true,
	) );

	register_taxonomy( 'job_category', 'job', array(
		'labels'       => array(
			'name'          => __( 'Job Categories', 'bd-garments-career' ),
			'singular_name' => __( 'Job Category', 'bd-garments-career' ),
			'search_items'  => __( 'Search Job Categories', 'bd-garments-career' ),
			'all_items'     => __( 'All Job Categories', 'bd-garments-career' ),
			'edit_item'     => __( 'Edit Job Category', 'bd-garments-career' ),
			'add_new_item'  => __( 'Add New Job Category', 'bd-garments-career' ),
			'menu_name'     => __( 'Job Categories', 'bd-garments-career' ),
		),
		'hierarchical' => true,
		'public'       => true,
		'rewrite'      => array( 'slug' => 'job-category', 'with_front' => false ),
		'show_in_rest' => true,
	) );

	register_taxonomy( 'job_location', 'job', array(
		'labels'       => array(
			'name'          => __( 'Locations', 'bd-garments-career' ),
			'singular_name' => __( 'Location', 'bd-garments-career' ),
			'search_items'  => __( 'Search Locations', 'bd-garments-career' ),
			'all_items'     => __( 'All Locations', 'bd-garments-career' ),
			'edit_item'     => __( 'Edit Location', 'bd-garments-career' ),
			'add_new_item'  => __( 'Add New Location', 'bd-garments-career' ),
			'menu_name'     => __( 'Locations', 'bd-garments-career' ),
		),
		'hierarchical' => true,
		'public'       => true,
		'rewrite'      => array( 'slug' => 'job-location', 'with_front' => false ),
		'show_in_rest' => true,
	) );

	register_taxonomy( 'job_type', 'job', array(
		'labels'       => array(
			'name'          => __( 'Job Types', 'bd-garments-career' ),
			'singular_name' => __( 'Job Type', 'bd-garments-career' ),
			'search_items'  => __( 'Search Job Types', 'bd-garments-career' ),
			'all_items'     => __( 'All Job Types', 'bd-garments-career' ),
			'edit_item'     => __( 'Edit Job Type', 'bd-garments-career' ),
			'add_new_item'  => __( 'Add New Job Type', 'bd-garments-career' ),
			'menu_name'     => __( 'Job Types', 'bd-garments-career' ),
		),
		'hierarchical' => true,
		'public'       => true,
		'rewrite'      => array( 'slug' => 'job-type', 'with_front' => false ),
		'show_in_rest' => true,
	) );
}
add_action( 'init', 'bdgc_register_job_type' );

/**
 * Register job meta keys.
 */
function bdgc_register_job_meta() {
	$keys = array( 'salary', 'deadline', 'experience' );
	foreach ( $keys as $key ) {
		register_post_meta( 'job', '_bdgc_' . $key, array(
			'show_in_rest' => true,
			'single'       => true,
			'type'         => 'string',
			'auth_callback' => function () {
				return current_user_can( 'edit_posts' );
			},
		) );
	}
	register_post_meta( 'job', '_bdgc_job_type', array(
		'show_in_rest'  => true,
		'single'        => true,
		'type'          => 'string',
		'auth_callback' => function () {
			return current_user_can( 'edit_posts' );
		},
	) );
}
add_action( 'init', 'bdgc_register_job_meta' );

/**
 * Get a job meta value.
 *
 * @param int    $post_id Post ID.
 * @param string $key     Meta key without prefix.
 * @return string
 */
function bdgc_get_job_meta( $post_id, $key ) {
	$value = get_post_meta( $post_id, '_bdgc_' . $key, true );
	if ( 'deadline' === $key && $value ) {
		$value = date_i18n( get_option( 'date_format' ), strtotime( $value ) );
	}
	return $value;
}

/**
 * Add the job meta box on the editor screen.
 */
function bdgc_job_metabox() {
	add_meta_box(
		'bdgc_job_details',
		__( 'Job Details', 'bd-garments-career' ),
		'bdgc_job_metabox_html',
		'job',
		'side',
		'high'
	);
}
add_action( 'add_meta_boxes', 'bdgc_job_metabox' );

/**
 * Render the job meta box fields.
 *
 * @param WP_Post $post Current post object.
 */
function bdgc_job_metabox_html( $post ) {
	wp_nonce_field( 'bdgc_job_meta', 'bdgc_job_meta_nonce' );
	$salary     = bdgc_get_job_meta( $post->ID, 'salary' );
	$deadline   = get_post_meta( $post->ID, '_bdgc_deadline', true );
	$experience = bdgc_get_job_meta( $post->ID, 'experience' );
	$job_type   = bdgc_get_job_meta( $post->ID, 'job_type' );
	?>
	<p>
		<label for="bdgc_salary"><?php esc_html_e( 'Salary (e.g. ৳25,000–30,000/month)', 'bd-garments-career' ); ?></label>
		<input type="text" id="bdgc_salary" name="bdgc_salary" class="widefat" value="<?php echo esc_attr( $salary ); ?>">
	</p>
	<p>
		<label for="bdgc_deadline"><?php esc_html_e( 'Application Deadline', 'bd-garments-career' ); ?></label>
		<input type="date" id="bdgc_deadline" name="bdgc_deadline" class="widefat" value="<?php echo esc_attr( $deadline ); ?>">
	</p>
	<p>
		<label for="bdgc_experience"><?php esc_html_e( 'Experience Required', 'bd-garments-career' ); ?></label>
		<input type="text" id="bdgc_experience" name="bdgc_experience" class="widefat" value="<?php echo esc_attr( $experience ); ?>" placeholder="<?php esc_attr_e( 'e.g. 2-3 years', 'bd-garments-career' ); ?>">
	</p>
	<p>
		<label for="bdgc_job_type"><?php esc_html_e( 'Employment Type', 'bd-garments-career' ); ?></label>
		<select id="bdgc_job_type" name="bdgc_job_type" class="widefat">
			<option value=""><?php esc_html_e( 'Select…', 'bd-garments-career' ); ?></option>
			<?php
			$types = bdgc_job_type_choices();
			foreach ( $types as $value => $label ) {
				printf(
					'<option value="%1$s" %2$s>%3$s</option>',
					esc_attr( $value ),
					selected( $job_type, $value, false ),
					esc_html( $label )
				);
			}
			?>
		</select>
	</p>
	<?php
}

/**
 * Save job meta box fields.
 *
 * @param int $post_id Post ID.
 */
function bdgc_job_save_meta( $post_id ) {
	if ( ! isset( $_POST['bdgc_job_meta_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['bdgc_job_meta_nonce'] ), 'bdgc_job_meta' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	$fields = array(
		'salary'     => 'sanitize_text_field',
		'experience' => 'sanitize_text_field',
		'job_type'   => 'sanitize_key',
	);
	foreach ( $fields as $key => $sanitize ) {
		if ( isset( $_POST[ 'bdgc_' . $key ] ) ) {
			$value = call_user_func( $sanitize, wp_unslash( $_POST[ 'bdgc_' . $key ] ) );
			update_post_meta( $post_id, '_bdgc_' . $key, $value );
		}
	}

	if ( isset( $_POST['bdgc_deadline'] ) ) {
		$deadline = sanitize_text_field( wp_unslash( $_POST['bdgc_deadline'] ) );
		if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $deadline ) ) {
			update_post_meta( $post_id, '_bdgc_deadline', $deadline );
		}
	}
}
add_action( 'save_post_job', 'bdgc_job_save_meta' );

/**
 * Employment type choices used by the meta box and job search block.
 *
 * @return array
 */
function bdgc_job_type_choices() {
	return array(
		'full-time'  => __( 'Full Time', 'bd-garments-career' ),
		'part-time'  => __( 'Part Time', 'bd-garments-career' ),
		'contract'   => __( 'Contract', 'bd-garments-career' ),
		'permanent'  => __( 'Permanent', 'bd-garments-career' ),
		'probation'  => __( 'Probation', 'bd-garments-career' ),
		'internship' => __( 'Internship', 'bd-garments-career' ),
	);
}

/**
 * Render the job search block.
 */
function bdgc_render_job_search() {
	ob_start();
	?>
	<form class="job-search" role="search" method="get" action="<?php echo esc_url( get_post_type_archive_link( 'job' ) ); ?>">
		<div class="job-search__field job-search__field--wide">
			<label class="screen-reader-text" for="bdgc-s"><?php esc_html_e( 'Search jobs', 'bd-garments-career' ); ?></label>
			<input type="search" id="bdgc-s" name="s" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="<?php esc_attr_e( 'Job title or keyword…', 'bd-garments-career' ); ?>">
		</div>
		<div class="job-search__field">
			<label class="screen-reader-text" for="bdgc-cat"><?php esc_html_e( 'Category', 'bd-garments-career' ); ?></label>
			<select id="bdgc-cat" name="job_category">
				<option value=""><?php esc_html_e( 'All Categories', 'bd-garments-career' ); ?></option>
				<?php
				$cats = get_terms( array( 'taxonomy' => 'job_category', 'hide_empty' => true ) );
				if ( $cats && ! is_wp_error( $cats ) ) {
					foreach ( $cats as $cat ) {
						printf(
							'<option value="%1$s" %2$s>%3$s</option>',
							esc_attr( $cat->slug ),
							selected( get_query_var( 'job_category' ), $cat->slug, false ),
							esc_html( $cat->name )
						);
					}
				}
				?>
			</select>
		</div>
		<div class="job-search__field">
			<label class="screen-reader-text" for="bdgc-loc"><?php esc_html_e( 'Location', 'bd-garments-career' ); ?></label>
			<select id="bdgc-loc" name="job_location">
				<option value=""><?php esc_html_e( 'All Locations', 'bd-garments-career' ); ?></option>
				<?php
				$locs = get_terms( array( 'taxonomy' => 'job_location', 'hide_empty' => true ) );
				if ( $locs && ! is_wp_error( $locs ) ) {
					foreach ( $locs as $loc ) {
						printf(
							'<option value="%1$s" %2$s>%3$s</option>',
							esc_attr( $loc->slug ),
							selected( get_query_var( 'job_location' ), $loc->slug, false ),
							esc_html( $loc->name )
						);
					}
				}
				?>
			</select>
		</div>
		<div class="job-search__field">
			<button type="submit" class="btn btn--primary btn--block"><?php esc_html_e( 'Search Jobs', 'bd-garments-career' ); ?></button>
		</div>
	</form>
	<?php
	return ob_get_clean();
}

/**
 * Front-end query for the jobs archive: newest first, optional search.
 *
 * @param WP_Query $query The main query.
 */
function bdgc_jobs_archive_query( $query ) {
	if ( is_admin() || ! $query->is_main_query() ) {
		return;
	}
	if ( $query->is_post_type_archive( 'job' ) || $query->is_tax( array( 'job_category', 'job_location', 'job_type' ) ) ) {
		$query->set( 'posts_per_page', 10 );
		$query->set( 'orderby', 'date' );
		$query->set( 'order', 'DESC' );
	}
}
add_action( 'pre_get_posts', 'bdgc_jobs_archive_query' );

/**
 * Admin columns for the jobs list table.
 *
 * @param array $columns Existing columns.
 * @return array
 */
function bdgc_job_admin_columns( $columns ) {
	$out = array();
	foreach ( $columns as $key => $label ) {
		$out[ $key ] = $label;
		if ( 'title' === $key ) {
			$out['bdgc_deadline_col'] = __( 'Deadline', 'bd-garments-career' );
			$out['bdgc_type_col']     = __( 'Type', 'bd-garments-career' );
		}
	}
	return $out;
}
add_filter( 'manage_job_posts_columns', 'bdgc_job_admin_columns' );

/**
 * Render admin column values for jobs.
 *
 * @param string $column  Column key.
 * @param int    $post_id Post ID.
 */
function bdgc_job_admin_column_content( $column, $post_id ) {
	if ( 'bdgc_deadline_col' === $column ) {
		$deadline = get_post_meta( $post_id, '_bdgc_deadline', true );
		echo $deadline ? esc_html( date_i18n( get_option( 'date_format' ), strtotime( $deadline ) ) ) : '&mdash;';
	}
	if ( 'bdgc_type_col' === $column ) {
		$type = bdgc_get_job_meta( $post_id, 'job_type' );
		$map  = bdgc_job_type_choices();
		echo isset( $map[ $type ] ) ? esc_html( $map[ $type ] ) : '&mdash;';
	}
}
add_action( 'manage_job_posts_custom_column', 'bdgc_job_admin_column_content', 10, 2 );
