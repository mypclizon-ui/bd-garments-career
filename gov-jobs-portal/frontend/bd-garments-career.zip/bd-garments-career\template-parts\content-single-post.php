<?php
/**
 * Single blog post content.
 *
 * @package BD_Garments_Career
 */
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'single-post' ); ?>>
	<header class="post-header">
		<h1 class="post-title"><?php the_title(); ?></h1>
		<ul class="post-meta">
			<li>
				<time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time>
			</li>
			<li><?php esc_html_e( 'by', 'bd-garments-career' ); ?> <?php the_author(); ?></li>
			<li>
				<?php printf( esc_html__( '%s min read', 'bd-garments-career' ), esc_html( bdgc_reading_time() ) ); ?>
			</li>
		</ul>
	</header>

	<?php if ( has_post_thumbnail() ) : ?>
		<div class="post-thumb">
			<?php the_post_thumbnail( 'bdgc-featured' ); ?>
		</div>
	<?php endif; ?>

	<div class="entry-content">
		<?php
		the_content();
		wp_link_pages( array(
			'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'bd-garments-career' ),
			'after'  => '</div>',
		) );
		?>
	</div>

	<footer class="post-footer">
		<?php the_tags( '<span class="tag-label">' . esc_html__( 'Tags:', 'bd-garments-career' ) . '</span> ', ', ', '' ); ?>
	</footer>
</article>
