<?php
/**
 * Front page: job categories grid.
 *
 * @package BD_Garments_Career
 */

$bdgc_cat_terms = get_terms( array(
	'taxonomy'   => 'job_category',
	'hide_empty' => false,
	'number'     => 8,
) );

$bdgc_icon_map = array(
	'sewing'        => 'scissors',
	'sweater'       => 'knitting',
	'knit'          => 'knitting',
	'textile'       => 'fabric',
	'fabric'        => 'fabric',
	'dyeing'        => 'droplet',
	'washing'       => 'droplet',
	'finishing'     => 'iron',
	'quality'       => 'badge',
	'merchandising' => 'clipboard',
	'sample'        => 'shirt',
	'production'    => 'factory',
	'printing'      => 'printer',
	'embroidery'    => 'shirt',
	'store'         => 'box',
	'hr'            => 'users',
	'admin'         => 'users',
	'it'            => 'monitor',
	'compliance'    => 'shield',
	'logistics'     => 'truck',
	'export'        => 'ship',
);
?>
<section class="categories section" id="categories">
	<div class="container">
		<div class="reveal">
			<?php
			bdgc_section_heading(
				__( 'Categories', 'bd-garments-career' ),
				bdgc_get_option( 'bdgc_cat_title', __( 'Browse Jobs by Category', 'bd-garments-career' ) ),
				bdgc_get_option( 'bdgc_cat_text', '' )
			);
			?>
		</div>

		<?php if ( $bdgc_cat_terms && ! is_wp_error( $bdgc_cat_terms ) ) : ?>
			<div class="categories__grid reveal reveal-zoom" data-stagger>
				<?php foreach ( $bdgc_cat_terms as $bdgc_term ) : ?>
					<?php
					$bdgc_count = $bdgc_term->count;
					$bdgc_icon  = 'briefcase';
					foreach ( $bdgc_icon_map as $bdgc_needle => $bdgc_icon_name ) {
						if ( false !== stripos( $bdgc_term->name, $bdgc_needle ) ) {
							$bdgc_icon = $bdgc_icon_name;
							break;
						}
					}
					?>
					<a class="category-card" href="<?php echo esc_url( get_term_link( $bdgc_term ) ); ?>">
						<span class="category-card__icon"><?php bdgc_icon( $bdgc_icon ); ?></span>
						<span class="category-card__name"><?php echo esc_html( $bdgc_term->name ); ?></span>
						<span class="category-card__count">
							<?php
							/* translators: %s: job count */
							printf( esc_html__( '%s Openings', 'bd-garments-career' ), esc_html( number_format_i18n( $bdgc_count ) ) );
							?>
						</span>
					</a>
				<?php endforeach; ?>
			</div>
		<?php else : ?>
			<p class="notice"><?php esc_html_e( 'No job categories yet. Add categories under Jobs → Job Categories to display them here.', 'bd-garments-career' ); ?></p>
		<?php endif; ?>
	</div>
</section>
