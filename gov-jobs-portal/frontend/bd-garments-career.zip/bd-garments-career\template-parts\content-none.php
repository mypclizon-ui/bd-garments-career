<?php
/**
 * Template part for displaying a "no results" message.
 *
 * @package BD_Garments_Career
 */
?>
<section class="no-results">
	<h2 class="no-results__title"><?php esc_html_e( 'Nothing Found', 'bd-garments-career' ); ?></h2>
	<?php if ( is_search() ) : ?>
		<p><?php esc_html_e( 'Sorry, nothing matched your search. Try different keywords.', 'bd-garments-career' ); ?></p>
		<?php get_search_form(); ?>
	<?php else : ?>
		<p><?php esc_html_e( 'No content here yet.', 'bd-garments-career' ); ?></p>
	<?php endif; ?>
</section>
