<?php
/**
 * Theme Customizer settings for BD Garments Career.
 *
 * Everything on the homepage and in the footer is editable live from
 * Appearance -> Customize.
 *
 * @package BD_Garments_Career
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register Customizer panels, sections and settings.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function bdgc_customize_register( $wp_customize ) {

	// ---------------------------------------------------------------- Panel.
	$wp_customize->add_panel( 'bdgc_homepage', array(
		'title'       => __( 'Homepage Sections', 'bd-garments-career' ),
		'description' => __( 'Manage all content shown on the front page.', 'bd-garments-career' ),
		'priority'    => 10,
	) );

	// ------------------------------------------------------------- Sections.
	$sections = array(
		'bdgc_hero'       => __( 'Hero / Banner', 'bd-garments-career' ),
		'bdgc_stats'      => __( 'Stats Bar', 'bd-garments-career' ),
		'bdgc_partners'   => __( 'Partners', 'bd-garments-career' ),
		'bdgc_categories' => __( 'Job Categories', 'bd-garments-career' ),
		'bdgc_about'      => __( 'About / Why Choose Us', 'bd-garments-career' ),
		'bdgc_jobs'       => __( 'Latest Jobs', 'bd-garments-career' ),
		'bdgc_how'        => __( 'How It Works', 'bd-garments-career' ),
		'bdgc_testi'      => __( 'Testimonials', 'bd-garments-career' ),
		'bdgc_cta'        => __( 'Call To Action', 'bd-garments-career' ),
		'bdgc_blog'       => __( 'Latest News', 'bd-garments-career' ),
		'bdgc_contact'    => __( 'Contact Info', 'bd-garments-career' ),
		'bdgc_footer'     => __( 'Footer', 'bd-garments-career' ),
		'bdgc_colors'     => __( 'Colors', 'bd-garments-career' ),
	);

	foreach ( $sections as $id => $label ) {
		$wp_customize->add_section( $id, array(
			'title' => $label,
			'panel' => ( 0 === strpos( $id, 'bdgc_hero' ) || 0 === strpos( $id, 'bdgc_footer' ) || 0 === strpos( $id, 'bdgc_colors' ) || 0 === strpos( $id, 'bdgc_contact' ) ) ? '' : 'bdgc_homepage',
		) );
	}

	// Helpers --------------------------------------------------------------.
	$text = array( 'sanitize_callback' => 'sanitize_text_field' );
	$area = array( 'sanitize_callback' => 'wp_kses_post' );
	$bool = array( 'sanitize_callback' => 'wp_validate_boolean' );
	$int  = array( 'sanitize_callback' => 'absint' );
	$url  = array( 'sanitize_callback' => 'esc_url_raw' );

	$wp_customize->add_setting( 'bdgc_primary_color', array(
		'default'           => '#6d4a7e',
		'sanitize_callback' => 'sanitize_hex_color',
	) );
	$wp_customize->add_setting( 'bdgc_primary_dark', array(
		'default'           => '#4a2d58',
		'sanitize_callback' => 'sanitize_hex_color',
	) );
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'bdgc_primary_color', array(
		'label'   => __( 'Primary Color', 'bd-garments-career' ),
		'section' => 'bdgc_colors',
	) ) );
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'bdgc_primary_dark', array(
		'label'   => __( 'Primary Dark Color', 'bd-garments-career' ),
		'section' => 'bdgc_colors',
	) ) );

	// Hero ----------------------------------------------------------------.
	$wp_customize->add_setting( 'bdgc_hero_title', array_merge( array( 'default' => __( 'Build Your Career with Confidence', 'bd-garments-career' ) ), $text ) );
	$wp_customize->add_control( 'bdgc_hero_title', array(
		'label'   => __( 'Hero Title', 'bd-garments-career' ),
		'section' => 'bdgc_hero',
		'type'    => 'text',
	) );

	$wp_customize->add_setting( 'bdgc_hero_sub', array_merge( array( 'default' => __( 'Connecting skilled workers with leading RMG factories, textile mills and export houses across Bangladesh. Free job posts, verified employers, daily updates.', 'bd-garments-career' ) ), $area ) );
	$wp_customize->add_control( 'bdgc_hero_sub', array(
		'label'   => __( 'Hero Subtext', 'bd-garments-career' ),
		'section' => 'bdgc_hero',
		'type'    => 'textarea',
	) );

	$wp_customize->add_setting( 'bdgc_hero_btn1_text', array_merge( array( 'default' => __( 'Explore Jobs', 'bd-garments-career' ) ), $text ) );
	$wp_customize->add_control( 'bdgc_hero_btn1_text', array(
		'label'   => __( 'Primary Button Text', 'bd-garments-career' ),
		'section' => 'bdgc_hero',
		'type'    => 'text',
	) );
	$wp_customize->add_setting( 'bdgc_hero_btn1_url', array_merge( array( 'default' => '#jobs' ), $url ) );
	$wp_customize->add_control( 'bdgc_hero_btn1_url', array(
		'label'   => __( 'Primary Button Link', 'bd-garments-career' ),
		'section' => 'bdgc_hero',
		'type'    => 'url',
	) );
	$wp_customize->add_setting( 'bdgc_hero_btn2_text', array_merge( array( 'default' => __( 'Learn More', 'bd-garments-career' ) ), $text ) );
	$wp_customize->add_control( 'bdgc_hero_btn2_text', array(
		'label'   => __( 'Secondary Button Text', 'bd-garments-career' ),
		'section' => 'bdgc_hero',
		'type'    => 'text',
	) );
	$wp_customize->add_setting( 'bdgc_hero_btn2_url', array_merge( array( 'default' => '#about' ), $url ) );
	$wp_customize->add_control( 'bdgc_hero_btn2_url', array(
		'label'   => __( 'Secondary Button Link', 'bd-garments-career' ),
		'section' => 'bdgc_hero',
		'type'    => 'url',
	) );

	$wp_customize->add_setting( 'bdgc_hero_image', array( 'sanitize_callback' => 'absint', 'default' => 0 ) );
	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'bdgc_hero_image', array(
		'label'   => __( 'Hero Image', 'bd-garments-career' ),
		'section' => 'bdgc_hero',
	) ) );

	// Stats ---------------------------------------------------------------.
	$stats_defaults = array(
		'bdgc_stat_1_value' => '100+',
		'bdgc_stat_1_label' => __( 'Career opportunities shared', 'bd-garments-career' ),
		'bdgc_stat_2_value' => '10+',
		'bdgc_stat_2_label' => __( 'Departments supported', 'bd-garments-career' ),
		'bdgc_stat_3_value' => '24/7',
		'bdgc_stat_3_label' => __( 'Easy access to updates', 'bd-garments-career' ),
		'bdgc_stat_4_value' => 'Trusted',
		'bdgc_stat_4_label' => __( 'Simple and reliable platform', 'bd-garments-career' ),
	);
	foreach ( $stats_defaults as $key => $default ) {
		$wp_customize->add_setting( $key, array_merge( array( 'default' => $default ), $text ) );
		$wp_customize->add_control( $key, array(
			'label'   => ucwords( str_replace( '_', ' ', substr( $key, 13 ) ) ),
			'section' => 'bdgc_stats',
			'type'    => 'text',
		) );
	}

	// Partners -------------------------------------------------------------.
	$wp_customize->add_setting( 'bdgc_partners_heading', array_merge( array( 'default' => __( 'Trusted by leading garment manufacturers', 'bd-garments-career' ) ), $text ) );
	$wp_customize->add_control( 'bdgc_partners_heading', array(
		'label'   => __( 'Section Heading', 'bd-garments-career' ),
		'section' => 'bdgc_partners',
		'type'    => 'text',
	) );
	$wp_customize->add_setting( 'bdgc_partners', array_merge( array( 'default' => __( "Apex Knitwear\nBeximco Textiles\nDBL Group\nEnvoy Textiles\nHa-Meem Group\nSuper Knitting", 'bd-garments-career' ) ), $area ) );
	$wp_customize->add_control( 'bdgc_partners', array(
		'label'       => __( 'Partner Names', 'bd-garments-career' ),
		'description' => __( 'One partner per line. Optionally add a link with a vertical bar: Name | https://example.com', 'bd-garments-career' ),
		'section'     => 'bdgc_partners',
		'type'        => 'textarea',
	) );

	// Categories ----------------------------------------------------------.
	$wp_customize->add_setting( 'bdgc_cat_title', array_merge( array( 'default' => __( 'Browse Jobs by Category', 'bd-garments-career' ) ), $text ) );
	$wp_customize->add_control( 'bdgc_cat_title', array(
		'label'   => __( 'Section Title', 'bd-garments-career' ),
		'section' => 'bdgc_categories',
		'type'    => 'text',
	) );
	$wp_customize->add_setting( 'bdgc_cat_text', array_merge( array( 'default' => __( 'From sewing operators to merchandisers — find opportunities across the whole apparel supply chain.', 'bd-garments-career' ) ), $area ) );
	$wp_customize->add_control( 'bdgc_cat_text', array(
		'label'   => __( 'Section Text', 'bd-garments-career' ),
		'section' => 'bdgc_categories',
		'type'    => 'textarea',
	) );

	// About ---------------------------------------------------------------.
	$wp_customize->add_setting( 'bdgc_about_title', array_merge( array( 'default' => __( 'About BD Garments Career', 'bd-garments-career' ) ), $text ) );
	$wp_customize->add_control( 'bdgc_about_title', array(
		'label'   => __( 'About Title', 'bd-garments-career' ),
		'section' => 'bdgc_about',
		'type'    => 'text',
	) );
	$wp_customize->add_setting( 'bdgc_about_text', array_merge( array( 'default' => __( 'We are dedicated to making job discovery easier for candidates and helping employers connect with the right talent. Our platform is designed to be clear, professional, and easy to use.', 'bd-garments-career' ) ), $area ) );
	$wp_customize->add_control( 'bdgc_about_text', array(
		'label'   => __( 'About Text', 'bd-garments-career' ),
		'section' => 'bdgc_about',
		'type'    => 'textarea',
	) );
	$wp_customize->add_setting( 'bdgc_about_points', array_merge( array( 'default' => __( "Clear job listings with simple navigation\nCareer-focused content for growth and learning\nFast search to find opportunities quickly\nProfessional design that builds trust", 'bd-garments-career' ) ), $area ) );
	$wp_customize->add_control( 'bdgc_about_points', array(
		'label'       => __( 'About Bullet Points', 'bd-garments-career' ),
		'description' => __( 'One point per line.', 'bd-garments-career' ),
		'section'     => 'bdgc_about',
		'type'        => 'textarea',
	) );
	$wp_customize->add_setting( 'bdgc_about_image', array( 'sanitize_callback' => 'absint', 'default' => 0 ) );
	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'bdgc_about_image', array(
		'label'   => __( 'About Image', 'bd-garments-career' ),
		'section' => 'bdgc_about',
	) ) );

	// Jobs ----------------------------------------------------------------.
	$wp_customize->add_setting( 'bdgc_jobs_title', array_merge( array( 'default' => __( 'Latest Job Openings', 'bd-garments-career' ) ), $text ) );
	$wp_customize->add_control( 'bdgc_jobs_title', array(
		'label'   => __( 'Section Title', 'bd-garments-career' ),
		'section' => 'bdgc_jobs',
		'type'    => 'text',
	) );
	$wp_customize->add_setting( 'bdgc_jobs_text', array_merge( array( 'default' => __( 'A few highlighted positions to help candidates get started quickly.', 'bd-garments-career' ) ), $area ) );
	$wp_customize->add_control( 'bdgc_jobs_text', array(
		'label'   => __( 'Section Text', 'bd-garments-career' ),
		'section' => 'bdgc_jobs',
		'type'    => 'textarea',
	) );
	$wp_customize->add_setting( 'bdgc_jobs_count', array_merge( array( 'default' => 6 ), $int ) );
	$wp_customize->add_control( 'bdgc_jobs_count', array(
		'label'   => __( 'Number of Jobs to Show', 'bd-garments-career' ),
		'section' => 'bdgc_jobs',
		'type'    => 'number',
	) );

	// How it works --------------------------------------------------------.
	$wp_customize->add_setting( 'bdgc_how_title', array_merge( array( 'default' => __( 'How It Works', 'bd-garments-career' ) ), $text ) );
	$wp_customize->add_control( 'bdgc_how_title', array(
		'label'   => __( 'Section Title', 'bd-garments-career' ),
		'section' => 'bdgc_how',
		'type'    => 'text',
	) );

	// Testimonials --------------------------------------------------------.
	$wp_customize->add_setting( 'bdgc_testi_title', array_merge( array( 'default' => __( 'What Workers & HR Managers Say', 'bd-garments-career' ) ), $text ) );
	$wp_customize->add_control( 'bdgc_testi_title', array(
		'label'   => __( 'Section Title', 'bd-garments-career' ),
		'section' => 'bdgc_testi',
		'type'    => 'text',
	) );

	// CTA -----------------------------------------------------------------.
	$wp_customize->add_setting( 'bdgc_cta_title', array_merge( array( 'default' => __( 'Are You Hiring for Your Factory?', 'bd-garments-career' ) ), $text ) );
	$wp_customize->add_control( 'bdgc_cta_title', array(
		'label'   => __( 'CTA Title', 'bd-garments-career' ),
		'section' => 'bdgc_cta',
		'type'    => 'text',
	) );
	$wp_customize->add_setting( 'bdgc_cta_text', array_merge( array( 'default' => __( 'Post your vacancies and reach thousands of skilled garment workers across Bangladesh — free and simple.', 'bd-garments-career' ) ), $area ) );
	$wp_customize->add_control( 'bdgc_cta_text', array(
		'label'   => __( 'CTA Text', 'bd-garments-career' ),
		'section' => 'bdgc_cta',
		'type'    => 'textarea',
	) );
	$wp_customize->add_setting( 'bdgc_cta_btn_text', array_merge( array( 'default' => __( 'Post a Job Now', 'bd-garments-career' ) ), $text ) );
	$wp_customize->add_control( 'bdgc_cta_btn_text', array(
		'label'   => __( 'CTA Button Text', 'bd-garments-career' ),
		'section' => 'bdgc_cta',
		'type'    => 'text',
	) );
	$wp_customize->add_setting( 'bdgc_cta_btn_url', array_merge( array( 'default' => '#contact' ), $url ) );
	$wp_customize->add_control( 'bdgc_cta_btn_url', array(
		'label'   => __( 'CTA Button Link', 'bd-garments-career' ),
		'section' => 'bdgc_cta',
		'type'    => 'url',
	) );

	// Blog ----------------------------------------------------------------.
	$wp_customize->add_setting( 'bdgc_blog_title', array_merge( array( 'default' => __( 'News & Career Tips', 'bd-garments-career' ) ), $text ) );
	$wp_customize->add_control( 'bdgc_blog_title', array(
		'label'   => __( 'Section Title', 'bd-garments-career' ),
		'section' => 'bdgc_blog',
		'type'    => 'text',
	) );

	// Contact -------------------------------------------------------------.
	$contact_defaults = array(
		'bdgc_phone'    => '+880 1712-345678',
		'bdgc_email'    => 'info@bdgarmentscareer.com',
		'bdgc_address'  => 'House 12, Road 5, Uttara, Dhaka 1230, Bangladesh',
		'bdgc_facebook' => 'https://facebook.com/bdgarmentscareer',
	);
	foreach ( $contact_defaults as $key => $default ) {
		$is_link = ( 0 === strpos( $key, 'bdgc_facebook' ) );
		$type    = $is_link ? 'url' : 'text';
		$wp_customize->add_setting( $key, array_merge( array( 'default' => $default ), ( $is_link ? $url : $text ) ) );
		$wp_customize->add_control( $key, array(
			'label'   => ucwords( str_replace( '_', ' ', substr( $key, 5 ) ) ),
			'section' => 'bdgc_contact',
			'type'    => $type,
		) );
	}

	// Footer --------------------------------------------------------------.
	$wp_customize->add_setting( 'bdgc_footer_text', array_merge( array( 'default' => __( 'Empowering the workforce behind Bangladesh’s $55 billion garment export industry.', 'bd-garments-career' ) ), $area ) );
	$wp_customize->add_control( 'bdgc_footer_text', array(
		'label'   => __( 'Footer Description', 'bd-garments-career' ),
		'section' => 'bdgc_footer',
		'type'    => 'textarea',
	) );
	$wp_customize->add_setting( 'bdgc_footer_credit', array_merge( array( 'default' => 'BD Garments Career' ), $text ) );
	$wp_customize->add_control( 'bdgc_footer_credit', array(
		'label'   => __( 'Footer Credit Text', 'bd-garments-career' ),
		'section' => 'bdgc_footer',
		'type'    => 'text',
	) );
}
add_action( 'customize_register', 'bdgc_customize_register' );

/**
 * Return dynamic CSS for Customizer color settings.
 *
 * @return string
 */
function bdgc_color_css() {
	$primary = bdgc_get_option( 'bdgc_primary_color', '#6d4a7e' );
	$dark    = bdgc_get_option( 'bdgc_primary_dark', '#4a2d58' );
	return sprintf(
		':root{--brand:%1$s;--brand-dark:%2$s;}',
		esc_attr( $primary ),
		esc_attr( $dark )
	);
}
add_action( 'wp_head', function () {
	echo '<style id="bdgc-color-css">' . bdgc_color_css() . '</style>'; // phpcs:ignore WordPress.Security.EscapeOutput
} );
