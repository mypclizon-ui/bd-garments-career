<?php
/**
 * Front page template.
 *
 * Assembles the Odoo-style marketing homepage: hero, stats, about,
 * featured jobs, categories/services, how it works, CTA and news.
 *
 * @package BD_Garments_Career
 */

get_header();
?>

<div class="front-page">
	<?php
	get_template_part( 'template-parts/front-page/hero' );
	get_template_part( 'template-parts/front-page/stats' );
	get_template_part( 'template-parts/front-page/about' );
	get_template_part( 'template-parts/front-page/jobs' );
	get_template_part( 'template-parts/front-page/categories' );
	get_template_part( 'template-parts/front-page/how' );
	get_template_part( 'template-parts/front-page/cta' );
	get_template_part( 'template-parts/front-page/blog' );
	get_template_part( 'template-parts/front-page/partners' );
	get_template_part( 'template-parts/front-page/testimonials' );
	?>
</div>

<?php
get_footer();
