<?php
/**
 * Front page: testimonials.
 *
 * @package BD_Garments_Career
 */

$bdgc_testimonials = array(
	array(
		'bdgc_name' => 'Rina Akter',
		'bdgc_role' => __( 'Sewing Operator, Dhaka', 'bd-garments-career' ),
		'bdgc_q'    => __( 'I found a job in a sweater factory within one week of joining. The factory was verified and I did not pay anyone anything.', 'bd-garments-career' ),
	),
	array(
		'bdgc_name' => 'Mahmudul Hasan',
		'bdgc_role' => __( 'Merchandiser, Chattogram', 'bd-garments-career' ),
		'bdgc_q'    => __( 'As an HR manager I post all our vacancies here. We get qualified candidates within days — much faster than local brokers.', 'bd-garments-career' ),
	),
	array(
		'bdgc_name' => 'Sharmin Sultana',
		'bdgc_role' => __( 'Quality Inspector, Gazipur', 'bd-garments-career' ),
		'bdgc_q'    => __( 'The job alerts on my phone saved me. I applied to five factories and got three interview calls in the same month.', 'bd-garments-career' ),
	),
);
?>
<section class="testimonials section" id="testimonials">
	<div class="container">
		<div class="reveal">
			<?php
			bdgc_section_heading(
				__( 'Testimonials', 'bd-garments-career' ),
				bdgc_get_option( 'bdgc_testi_title', __( 'What Workers & HR Managers Say', 'bd-garments-career' ) )
			);
			?>
		</div>

		<div class="testimonials__grid reveal reveal-zoom" data-stagger>
			<?php foreach ( $bdgc_testimonials as $bdgc_t ) : ?>
				<figure class="testimonial">
					<div class="testimonial__stars" aria-hidden="true">★★★★★</div>
					<blockquote class="testimonial__quote"><?php echo esc_html( $bdgc_t['bdgc_q'] ); ?></blockquote>
					<figcaption class="testimonial__author">
						<span class="testimonial__name"><?php echo esc_html( $bdgc_t['bdgc_name'] ); ?></span>
						<span class="testimonial__role"><?php echo esc_html( $bdgc_t['bdgc_role'] ); ?></span>
					</figcaption>
				</figure>
			<?php endforeach; ?>
		</div>
	</div>
</section>
