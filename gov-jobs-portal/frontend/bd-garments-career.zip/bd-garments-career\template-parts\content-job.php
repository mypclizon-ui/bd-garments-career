<?php
/**
 * Job listing card (used on the jobs archive + front page).
 *
 * @package BD_Garments_Career
 */

$bdgc_types  = bdgc_job_type_choices();
$bdgc_type   = bdgc_get_job_meta( get_the_ID(), 'job_type' );
$bdgc_loc    = get_the_terms( get_the_ID(), 'job_location' );
$bdgc_salary = bdgc_get_job_meta( get_the_ID(), 'salary' );
$bdgc_dead   = bdgc_get_job_meta( get_the_ID(), 'deadline' );
$bdgc_cats   = get_the_terms( get_the_ID(), 'job_category' );
?>
<article <?php post_class( 'job-card' ); ?>>
	<div class="job-card__body">
		<div class="job-card__head">
			<?php if ( $bdgc_type && isset( $bdgc_types[ $bdgc_type ] ) ) : ?>
				<span class="badge"><?php echo esc_html( $bdgc_types[ $bdgc_type ] ); ?></span>
			<?php endif; ?>
			<h3 class="job-card__title">
				<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
			</h3>
		</div>

		<ul class="job-card__meta">
			<?php if ( $bdgc_cats ) : ?>
				<li class="job-meta-item">
					<?php bdgc_icon( 'briefcase' ); ?>
					<span><?php echo esc_html( $bdgc_cats[0]->name ); ?></span>
				</li>
			<?php endif; ?>
			<?php if ( $bdgc_loc ) : ?>
				<li class="job-meta-item">
					<?php bdgc_icon( 'map-pin' ); ?>
					<span><?php echo esc_html( $bdgc_loc[0]->name ); ?></span>
				</li>
			<?php endif; ?>
			<?php if ( $bdgc_salary ) : ?>
				<li class="job-meta-item">
					<?php bdgc_icon( 'wallet' ); ?>
					<span><?php echo esc_html( $bdgc_salary ); ?></span>
				</li>
			<?php endif; ?>
			<?php if ( $bdgc_dead ) : ?>
				<li class="job-meta-item">
					<?php bdgc_icon( 'calendar' ); ?>
					<span><?php printf( esc_html__( 'Deadline: %s', 'bd-garments-career' ), esc_html( $bdgc_dead ) ); ?></span>
				</li>
			<?php endif; ?>
		</ul>
	</div>

	<div class="job-card__action">
		<a class="btn btn--primary btn--sm" href="<?php the_permalink(); ?>">
			<?php esc_html_e( 'View Details', 'bd-garments-career' ); ?>
		</a>
	</div>
</article>
