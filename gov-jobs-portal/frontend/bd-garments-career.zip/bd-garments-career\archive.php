<?php
/**
 * The template for displaying archive pages (categories, tags, authors).
 *
 * @package BD_Garments_Career
 */

get_header();

get_template_part( 'template-parts/hero', 'archive' );
?>

<div class="container archive-layout">
	<div class="archive-layout__main">
		<?php if ( have_posts() ) : ?>

			<div class="blog-grid blog-grid--list">
				<?php
				while ( have_posts() ) :
					the_post();
					get_template_part( 'template-parts/content', 'card' );
				endwhile;
				?>
			</div>

			<?php bdgc_pagination(); ?>

		<?php else : ?>

			<?php get_template_part( 'template-parts/content', 'none' ); ?>

		<?php endif; ?>
	</div>

	<?php get_sidebar(); ?>
</div>

<?php
get_footer();
