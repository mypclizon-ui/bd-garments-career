<?php
/**
 * Template tags for BD Garments Career.
 *
 * @package BD_Garments_Career
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Print the site logo or the blog name.
 */
function bdgc_site_logo() {
	if ( has_custom_logo() ) {
		the_custom_logo();
		return;
	}
	printf(
		'<a class="custom-logo-link brand-text" href="%1$s" rel="home">%2$s</a>',
		esc_url( home_url( '/' ) ),
		esc_html( get_bloginfo( 'name' ) )
	);
}

/**
 * Print the footer copyright line.
 */
function bdgc_copyright() {
	$year = gmdate( 'Y' );
	printf(
		/* translators: 1: year, 2: site name */
		esc_html__( '© %1$s %2$s. All rights reserved.', 'bd-garments-career' ),
		esc_html( $year ),
		esc_html( get_bloginfo( 'name' ) )
	);
}

/**
 * Reading time estimate for a post.
 */
function bdgc_reading_time() {
	$content = get_post_field( 'post_content', get_the_ID() );
	$words   = str_word_count( wp_strip_all_tags( $content ) );
	$mins    = max( 1, (int) ceil( $words / 200 ) );
	return $mins;
}

/**
 * Output an inline SVG icon by name.
 *
 * @param string $name Icon file name without extension.
 */
function bdgc_icon( $name ) {
	$svg_file = BDGC_DIR . '/assets/svg/' . sanitize_file_name( $name ) . '.svg';
	if ( file_exists( $svg_file ) ) {
		$svg = file_get_contents( $svg_file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		echo $svg; // phpcs:ignore WordPress.Security.EscapeOutput -- Static trusted SVG assets.
	}
}

/**
 * Pagination links for job/blog archives.
 */
function bdgc_pagination() {
	the_posts_pagination( array(
		'mid_size'  => 2,
		'prev_text' => '&larr;',
		'next_text' => '&rarr;',
	) );
}
