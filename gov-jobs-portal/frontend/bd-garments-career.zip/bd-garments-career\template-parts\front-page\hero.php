<?php
/**
 * Front page: hero section (Odoo-style split hero).
 *
 * @package BD_Garments_Career
 */

$bdgc_hero_title = bdgc_get_option( 'bdgc_hero_title', __( 'Build Your Career with Confidence', 'bd-garments-career' ) );
$bdgc_hero_sub   = bdgc_get_option( 'bdgc_hero_sub', '' );
$bdgc_btn1_text  = bdgc_get_option( 'bdgc_hero_btn1_text', __( 'Explore Jobs', 'bd-garments-career' ) );
$bdgc_btn1_url   = bdgc_get_option( 'bdgc_hero_btn1_url', '#jobs' );
$bdgc_btn2_text  = bdgc_get_option( 'bdgc_hero_btn2_text', __( 'Learn More', 'bd-garments-career' ) );
$bdgc_btn2_url   = bdgc_get_option( 'bdgc_hero_btn2_url', '#about' );
$bdgc_hero_img   = bdgc_get_option( 'bdgc_hero_image', 0 );
?>
<section class="hero">
	<div class="hero__blob hero__blob--1" aria-hidden="true"></div>
	<div class="hero__blob hero__blob--2" aria-hidden="true"></div>

	<div class="container hero__inner">
		<div class="hero__content reveal reveal-left">
			<h1 class="hero__title"><?php echo esc_html( $bdgc_hero_title ); ?></h1>
			<?php if ( $bdgc_hero_sub ) : ?>
				<p class="hero__sub"><?php echo esc_html( $bdgc_hero_sub ); ?></p>
			<?php endif; ?>
			<div class="hero__actions">
				<a class="btn btn--primary btn--lg" href="<?php echo esc_url( $bdgc_btn1_url ); ?>"><?php echo esc_html( $bdgc_btn1_text ); ?></a>
				<a class="btn btn--outline btn--lg" href="<?php echo esc_url( $bdgc_btn2_url ); ?>"><?php echo esc_html( $bdgc_btn2_text ); ?></a>
			</div>
		</div>

		<div class="hero__media reveal reveal-right">
			<?php if ( $bdgc_hero_img ) : ?>
				<img class="hero__img" src="<?php echo esc_url( wp_get_attachment_image_url( $bdgc_hero_img, 'bdgc-featured' ) ); ?>" alt="<?php esc_attr_e( 'Garments professionals working together', 'bd-garments-career' ); ?>" loading="eager">
			<?php endif; ?>

			<div class="quick-search">
				<h2 class="quick-search__title"><?php esc_html_e( 'Quick Search', 'bd-garments-career' ); ?></h2>
				<?php echo bdgc_render_job_search(); // phpcs:ignore WordPress.Security.EscapeOutput ?>
				<p class="quick-search__hint"><?php esc_html_e( 'Find openings and career updates in seconds.', 'bd-garments-career' ); ?></p>
			</div>
		</div>
	</div>
</section>
