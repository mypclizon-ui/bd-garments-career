<?php
/**
 * Front page: featured jobs (Odoo "Featured Openings" style).
 *
 * @package BD_Garments_Career
 */

$bdgc_jobs_query = new WP_Query( array(
	'post_type'      => 'job',
	'posts_per_page' => (int) bdgc_get_option( 'bdgc_jobs_count', 6 ),
	'no_found_rows'  => true,
) );
?>
<section class="featured-jobs section" id="jobs">
	<div class="container">
		<div class="section-head is-center reveal">
			<span class="kicker"><?php esc_html_e( 'Featured Openings', 'bd-garments-career' ); ?></span>
			<h2 class="section-title"><?php echo esc_html( bdgc_get_option( 'bdgc_jobs_title', __( 'Latest Job Openings', 'bd-garments-career' ) ) ); ?></h2>
			<p class="section-text"><?php echo esc_html( bdgc_get_option( 'bdgc_jobs_text', __( 'A few highlighted positions to help candidates get started quickly.', 'bd-garments-career' ) ) ); ?></p>
		</div>

		<?php if ( $bdgc_jobs_query->have_posts() ) : ?>
			<div class="jobs__grid reveal reveal-zoom" data-stagger>
				<?php
				while ( $bdgc_jobs_query->have_posts() ) :
					$bdgc_jobs_query->the_post();
					get_template_part( 'template-parts/content', 'job' );
				endwhile;
				wp_reset_postdata();
				?>
			</div>

			<div class="jobs__footer">
				<a class="btn btn--light btn--lg" href="<?php echo esc_url( get_post_type_archive_link( 'job' ) ); ?>">
					<?php esc_html_e( 'View All Jobs', 'bd-garments-career' ); ?>
				</a>
			</div>
		<?php else : ?>
			<p class="notice"><?php esc_html_e( 'No jobs posted yet. Add your first job from the WordPress dashboard under Jobs → Add New.', 'bd-garments-career' ); ?></p>
		<?php endif; ?>
	</div>
</section>
