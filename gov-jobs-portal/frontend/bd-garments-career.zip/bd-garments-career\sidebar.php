<?php
/**
 * The sidebar containing the main widget area.
 *
 * @package BD_Garments_Career
 */

if ( ! is_active_sidebar( 'sidebar-blog' ) ) {
	return;
}
?>
<aside class="sidebar">
	<?php dynamic_sidebar( 'sidebar-blog' ); ?>
</aside>
