<?php
/**
 * Page header template part (title + subtitle for inner pages).
 *
 * @package BD_Garments_Career
 */

$bdgc_subtitle = get_post_meta( get_the_ID(), '_bdgc_page_subtitle', true );
?>
<header class="page-hero">
	<div class="container">
		<h1 class="page-hero__title"><?php single_post_title(); ?></h1>
		<?php if ( $bdgc_subtitle ) : ?>
			<p class="page-hero__desc"><?php echo esc_html( $bdgc_subtitle ); ?></p>
		<?php endif; ?>
	</div>
</header>
