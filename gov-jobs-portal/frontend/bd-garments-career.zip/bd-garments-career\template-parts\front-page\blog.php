<?php
/**
 * Front page: latest news (blog posts).
 *
 * @package BD_Garments_Career
 */

$bdgc_blog_query = new WP_Query( array(
	'posts_per_page'      => 3,
	'ignore_sticky_posts' => true,
	'no_found_rows'       => true,
) );
?>
<section class="blog-preview section" id="news">
	<div class="container">
		<div class="reveal">
			<?php
			bdgc_section_heading(
				__( 'From the Blog', 'bd-garments-career' ),
				bdgc_get_option( 'bdgc_blog_title', __( 'News & Career Tips', 'bd-garments-career' ) )
			);
			?>
		</div>

		<?php if ( $bdgc_blog_query->have_posts() ) : ?>
			<div class="blog-grid reveal reveal-zoom" data-stagger>
				<?php
				while ( $bdgc_blog_query->have_posts() ) :
					$bdgc_blog_query->the_post();
					get_template_part( 'template-parts/content', 'card' );
				endwhile;
				wp_reset_postdata();
				?>
			</div>

			<div class="blog-preview__footer">
				<a class="btn btn--outline btn--lg" href="<?php echo esc_url( get_permalink( get_option( 'page_for_posts' ) ) ?: home_url( '/blog/' ) ); ?>">
					<?php esc_html_e( 'View All Articles', 'bd-garments-career' ); ?>
				</a>
			</div>
		<?php else : ?>
			<p class="notice"><?php esc_html_e( 'No articles yet. Write your first career tip from Posts → Add New.', 'bd-garments-career' ); ?></p>
		<?php endif; ?>
	</div>
</section>
