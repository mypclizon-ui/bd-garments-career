<?php
/**
 * Template Name: Legal / Info Page
 * Template Post Type: page
 *
 * A clean, readable template for information pages such as the Privacy
 * Policy, Terms & Conditions and similar. Content is fully controlled by
 * the WordPress page editor — this template only wraps it in a structured,
 * easy-to-read layout.
 *
 * @package BD_Garments_Career
 */

get_header();

get_template_part( 'template-parts/hero', 'page' );
?>

<main id="primary" class="site-main">
	<div class="container page-layout">
		<article id="post-<?php the_ID(); ?>" <?php post_class( 'page-layout__main' ); ?>>
			<div class="entry-content info-content">
				<?php
				the_content();
				wp_link_pages( array(
					'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'bd-garments-career' ),
					'after'  => '</div>',
				) );
				?>
			</div>

			<div class="info-updated">
				<?php
				printf(
					/* translators: %s: last modified date */
					esc_html__( 'Last updated: %s', 'bd-garments-career' ),
					esc_html( get_the_modified_date() )
				);
				?>
			</div>
		</article>
	</div>
</main>

<?php
get_footer();