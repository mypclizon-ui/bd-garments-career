<?php
/**
 * Front page: about section.
 *
 * @package BD_Garments_Career
 */

$bdgc_about_title = bdgc_get_option( 'bdgc_about_title', __( 'About BD Garments Career', 'bd-garments-career' ) );
$bdgc_about_text  = bdgc_get_option( 'bdgc_about_text', __( 'We are dedicated to making job discovery easier for candidates and helping employers connect with the right talent. Our platform is designed to be clear, professional, and easy to use.', 'bd-garments-career' ) );
$bdgc_about_img   = bdgc_get_option( 'bdgc_about_image', 0 );
$bdgc_points_raw  = bdgc_get_option( 'bdgc_about_points', '' );
$bdgc_points      = array_filter( array_map( 'trim', explode( "\n", $bdgc_points_raw ) ) );
?>
<section class="about section" id="about">
	<div class="container about__inner">

		<div class="about__card about__card--light reveal reveal-left">
			<span class="kicker"><?php esc_html_e( 'About BD Garments Career', 'bd-garments-career' ); ?></span>
			<h2 class="section-title"><?php echo esc_html( $bdgc_about_title ); ?></h2>
			<p class="about__text"><?php echo esc_html( $bdgc_about_text ); ?></p>
		</div>

		<div class="about__card about__card--cream reveal reveal-right">
			<h3 class="about__card-title"><?php esc_html_e( 'Why people choose us', 'bd-garments-career' ); ?></h3>
			<?php if ( $bdgc_points ) : ?>
				<ul class="check-list">
					<?php foreach ( $bdgc_points as $bdgc_point ) : ?>
						<li><?php echo esc_html( $bdgc_point ); ?></li>
					<?php endforeach; ?>
				</ul>
			<?php else : ?>
				<ul class="check-list">
					<li><?php esc_html_e( 'Clear job listings with simple navigation', 'bd-garments-career' ); ?></li>
					<li><?php esc_html_e( 'Career-focused content for growth and learning', 'bd-garments-career' ); ?></li>
					<li><?php esc_html_e( 'Fast search to find opportunities quickly', 'bd-garments-career' ); ?></li>
					<li><?php esc_html_e( 'Professional design that builds trust', 'bd-garments-career' ); ?></li>
				</ul>
			<?php endif; ?>
		</div>

		<?php if ( $bdgc_about_img ) : ?>
			<div class="about__media reveal reveal-zoom">
				<img src="<?php echo esc_url( wp_get_attachment_image_url( $bdgc_about_img, 'bdgc-featured' ) ); ?>" alt="<?php echo esc_attr( $bdgc_about_title ); ?>" loading="lazy">
			</div>
		<?php endif; ?>
	</div>
</section>
