<?php
/**
 * Blog / post card.
 *
 * @package BD_Garments_Career
 */
?>
<article <?php post_class( 'post-card' ); ?>>
	<?php if ( has_post_thumbnail() ) : ?>
		<a class="post-card__media" href="<?php the_permalink(); ?>">
			<?php the_post_thumbnail( 'bdgc-job-thumb' ); ?>
		</a>
	<?php endif; ?>

	<div class="post-card__body">
		<ul class="post-card__meta">
			<li>
				<time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time>
			</li>
			<li><?php esc_html_e( 'by', 'bd-garments-career' ); ?> <?php the_author(); ?></li>
		</ul>
		<h3 class="post-card__title">
			<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
		</h3>
		<p class="post-card__excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 20 ) ); ?></p>
		<a class="read-more" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Read More', 'bd-garments-career' ); ?> &rarr;</a>
	</div>
</article>
