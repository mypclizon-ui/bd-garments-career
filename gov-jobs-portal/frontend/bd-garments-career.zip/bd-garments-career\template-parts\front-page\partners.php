<?php
/**
 * Front page: partner / trusted-by logos slider.
 *
 * Editable from Appearance -> Customize -> Homepage Sections -> Partners.
 * Partners are managed as a newline-separated "Name | Logo URL" list so the
 * section works with or without custom imagery.
 *
 * @package BD_Garments_Career
 */

$bdgc_partners_heading = bdgc_get_option(
	'bdgc_partners_heading',
	__( 'Trusted by leading garment manufacturers', 'bd-garments-career' )
);
$bdgc_partners_raw = bdgc_get_option( 'bdgc_partners', '' );

$bdgc_partners = array();
foreach ( preg_split( '/\R/', trim( (string) $bdgc_partners_raw ) ) as $bdgc_line ) {
	$bdgc_line = trim( $bdgc_line );
	if ( '' === $bdgc_line ) {
		continue;
	}
	$parts = array_map( 'trim', explode( '|', $bdgc_line ) );
	$bdgc_partners[] = array(
		'name' => $parts[0],
		'logo' => ! empty( $parts[1] ) ? $parts[1] : '',
	);
}

// Sensible defaults when nothing has been configured yet.
if ( empty( $bdgc_partners ) ) {
	$bdgc_partners = array(
		array( 'name' => 'Apex Knitwear', 'logo' => '' ),
		array( 'name' => 'Beximco Textiles', 'logo' => '' ),
		array( 'name' => 'DBL Group', 'logo' => '' ),
		array( 'name' => 'Envoy Textiles', 'logo' => '' ),
		array( 'name' => 'Ha-Meem Group', 'logo' => '' ),
		array( 'name' => 'Super Knitting', 'logo' => '' ),
	);
}
?>
<section class="partners section" id="partners">
	<div class="container">
		<div class="section-head is-center reveal">
			<span class="kicker"><?php esc_html_e( 'Our Partners', 'bd-garments-career' ); ?></span>
			<h2 class="section-title"><?php echo esc_html( $bdgc_partners_heading ); ?></h2>
		</div>

		<?php if ( count( $bdgc_partners ) > 1 ) : ?>
			<div class="partners-slider reveal reveal-zoom">
				<div class="partners-slider__track" id="bdgc-partners-track">
					<?php foreach ( $bdgc_partners as $bdgc_partner ) : ?>
						<div class="partner-item">
							<div class="partner-item__logo">
								<?php if ( ! empty( $bdgc_partner['logo'] ) ) : ?>
									<img src="<?php echo esc_url( $bdgc_partner['logo'] ); ?>" alt="<?php echo esc_attr( $bdgc_partner['name'] ); ?>" loading="lazy">
								<?php else : ?>
									<span class="partner-item__monogram" aria-hidden="true"><?php echo esc_html( mb_substr( $bdgc_partner['name'], 0, 1 ) ); ?></span>
								<?php endif; ?>
								<span class="partner-item__name"><?php echo esc_html( $bdgc_partner['name'] ); ?></span>
							</div>
						</div>
					<?php endforeach; ?>
				</div>

				<button class="partners-slider__btn partners-slider__btn--prev" type="button" aria-label="<?php esc_attr_e( 'Previous partners', 'bd-garments-career' ); ?>" data-slide="-1">&#8249;</button>
				<button class="partners-slider__btn partners-slider__btn--next" type="button" aria-label="<?php esc_attr_e( 'Next partners', 'bd-garments-career' ); ?>" data-slide="1">&#8250;</button>
			</div>
		<?php else : ?>
			<div class="partners-static">
				<?php foreach ( $bdgc_partners as $bdgc_partner ) : ?>
					<div class="partner-item">
						<div class="partner-item__logo">
							<?php if ( ! empty( $bdgc_partner['logo'] ) ) : ?>
								<img src="<?php echo esc_url( $bdgc_partner['logo'] ); ?>" alt="<?php echo esc_attr( $bdgc_partner['name'] ); ?>" loading="lazy">
							<?php else : ?>
								<span class="partner-item__monogram" aria-hidden="true"><?php echo esc_html( mb_substr( $bdgc_partner['name'], 0, 1 ) ); ?></span>
							<?php endif; ?>
							<span class="partner-item__name"><?php echo esc_html( $bdgc_partner['name'] ); ?></span>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
	</div>
</section>