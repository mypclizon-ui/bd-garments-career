# Start the full BD Garments Career stack:
#   databases (Docker) -> backends (uvicorn) -> frontends (Next.js)
# Run from the repository root:  .\scripts\start-all.ps1

$ErrorActionPreference = "Stop"
$root = Split-Path $PSScriptRoot -Parent

Write-Host "==> Starting databases (Docker)..." -ForegroundColor Cyan
docker compose -f "$root\docker-compose.yml" up -d

Write-Host "==> Starting main-portal backend (port 8000)..." -ForegroundColor Cyan
Start-Process -FilePath "$root\main-portal\backend\venv\Scripts\python.exe" `
  -ArgumentList "-m","uvicorn","app.main:app","--port","8000" `
  -WorkingDirectory "$root\main-portal\backend" -WindowStyle Hidden

Write-Host "==> Starting gov-jobs backend (port 8100)..." -ForegroundColor Cyan
Start-Process -FilePath "$root\main-portal\backend\venv\Scripts\python.exe" `
  -ArgumentList "-m","uvicorn","app.main:app","--port","8100" `
  -WorkingDirectory "$root\gov-jobs-portal\backend" -WindowStyle Hidden

Write-Host "==> Starting main-portal frontend (port 3000)..." -ForegroundColor Cyan
Start-Process -FilePath "npm" -ArgumentList "start" `
  -WorkingDirectory "$root\main-portal\frontend" -WindowStyle Hidden

Write-Host "==> Starting gov-jobs frontend (port 3100)..." -ForegroundColor Cyan
Start-Process -FilePath "npm" -ArgumentList "start" `
  -WorkingDirectory "$root\gov-jobs-portal\frontend" -WindowStyle Hidden

Write-Host ""
Write-Host "All services launching:" -ForegroundColor Green
Write-Host "  Main portal   : http://localhost:3000   (backend :8000)"
Write-Host "  Gov jobs site : http://localhost:3100   (backend :8100)"
Write-Host "  WordPress     : http://localhost:8080/wordpress"
Write-Host ""
Write-Host "Run .\scripts\stop-all.ps1 to stop the services." -ForegroundColor Yellow