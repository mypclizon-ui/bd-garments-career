# Stop all services started by start-all.ps1 (backends on :8000 / :8100,
# frontends on :3000 / :3100). Databases via Docker are left running;
# stop them separately with `docker compose down`.

$ports = 3000, 3100, 8000, 8100

foreach ($port in $ports) {
    $listener = Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue
    if ($listener) {
        foreach ($conn in $listener) {
            Stop-Process -Id $conn.OwningProcess -Force -ErrorAction SilentlyContinue
            Write-Host "Stopped process on port $port (PID $($conn.OwningProcess))" -ForegroundColor Cyan
        }
    }
}
Write-Host "All frontends and backends stopped." -ForegroundColor Green
Write-Host "Docker databases are still running (docker compose down to stop them)." -ForegroundColor Yellow